<?php 
    $title = "IDCP - User Profile";
    require('includes/header.php');
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/user_helpers.php' ) ;
    $user_id = $_SESSION['user_id'];

?>


<style>
    .inline {
  display: inline;
}

.link-button {
  background: none;
  border: none;

}
.link-button:focus {
  outline: none;


}

.link-button:hover {
  outline: none;
  

}
.link-button:active {
  color:white;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="page-header">
                    <h1>
                        <?php
                            echo get_user_name($dbc, $user_id);
                        ?>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Account Information</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <p><label>User ID: </label><br>
                                    <?php
                                     echo $user_id;
                                    ?>
                                    </p>
                                    <p><label>Username:</label><br>
                                    <?php
                                      echo get_user_name($dbc, $user_id);
                                    ?>
                                    </p>
                                    <p><label>Role:</label><br>
                                    <?php
                                      echo get_user_role($dbc, $user_id);
                                    ?>
                                    </p>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='user_edit.php';">Edit</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='user_change_pwd.php';">Change Password</button>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-default btn-sm" onclick ="location.href='home.php';">Back</button>
                    </div>
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Task</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <button class="btn btn-default btn-sm" onclick ="location.href='user_create.php';">Create New User</button>
                                </div>
                            </div>
                        </div>
                    </div>
            <!-- /#container close -->
            </div>
            <!--<br>-->
            <!--<h3>Users</h3>-->
            <!--<div id="field_display" class="span3" style="height: 200px; overflow: auto;"> -->
            <!--    <?php-->
            <!--        show_brief_users_results($dbc, $searchString);-->
            <!--    ?>-->
            <!--</div>-->
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
