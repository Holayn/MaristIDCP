<!--User is redirected to this page after adding a student. Allows them to add courses for that student, or exit back to home page -->
<?php 
    $title = 'IDCP - Add Program for Student';
    require('includes/header.php');
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/student_helpers.php' ) ;
?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <div class="page-header">
    				    <?php
    				        $stu_id = $_SESSION['stu_id'];
    				        $name = get_stu_name($dbc, $stu_id);
    				        if($_SESSION['addedProgram'] == true){
    				            echo '<h1>Add More Programs for ' . "$name" . '</h1>';
    				        }
    				        else{
    				            echo '<h1>Add Program for ' . "$name" . '</h1>';
    				        }
    				    ?>
    				</div>
                    <div class = "butspan" style = "width: 300px;">
                        <button type="button" class="btn btn-primary btn-block" style = "margin-right: 50px;" onclick="location.href='add_student_program.php';">
				        <?php
				        $stu_id = $_SESSION['stu_id'];
				        $name = get_stu_name($dbc, $stu_id);
				        if($_SESSION['addedProgram'] == true){
				            echo 'Add Another Program for ' . "$name";
				        }
				        else{
				           echo 'Add a Program for ' . "$name";
				        }
				    ?></button>
				    <hr>
				        <!--Dynamic button-->
				        <?php
				        $stu_id = $_SESSION['stu_id'];
				        $name = get_stu_name($dbc, $stu_id);
				        if($_SESSION['addedProgram'] == true){
				            //This line below might not work
				            echo '<button type="button" class="btn btn-primary btn-block" style = "margin-right: 50px;" onclick="location.href=\'add_student_course_home.php\';">';
				            echo 'Add Courses for ' . "$name";
				            echo "</button>";
				        }
				        else{
				           echo '<p>Please add a program before proceeding</p>';
				        }
				        ?>
                </div>
                <?php
		            $stu_id = $_SESSION['stu_id'];
		            get_student_programs($dbc, $stu_id);
		        ?>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!--Student JavaScript -->
    <script src="js/student.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>
