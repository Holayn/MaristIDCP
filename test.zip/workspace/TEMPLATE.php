<?php
    $title = "TEMPLATE";
    require('includes/header.php');
?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <div class="page-header">
                        <h1>Welcome</h1>
                    </div>
                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select a Program:
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                      <li><a href="zOS.html">z/OS</a></li>
                      <li><a href="#">Data Center</a></li>
                    </ul>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>
