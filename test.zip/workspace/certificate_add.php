<?php
    $title = "IDCP - Add Certificate";
    require('includes/header.php');
    # Connect to MySQL server and the database
    require( 'includes/connect_db_c9.php' ) ;
    # Includes these helper functions
    require( 'includes/certificate_helpers.php' ) ;
    # Check to make sure it is the first time user is visiting the page
    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    	$cert_id = "";
    	$cert_name = "";
    	$prg_name = "";
    	$prg_id = "";
    }
    # Check to make sure the form method is post
    if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    	$cert_id = $_POST['cert_id'];
    	$cert_name = $_POST['cert_name'];
    	$prg_name = $_POST['prg_name'];
		$cert_id = trim($cert_id);
		$cert_name = trim($cert_name);
		$prg_name = trim($prg_name);
		$prg_id = get_prg_id($dbc, $prg_name);
	    $result = insert_certificate($dbc, $cert_id, $cert_name, $prg_id);
		$page = 'certificate_add_success.php';
		header("Location: $page");
    }
     mysqli_close( $dbc ) ;
?>
<style>
.button {
    background-color: darkred;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container" style="padding-right: 100px; max-width: 1100px;">
                <div class="dropdown">
                    <h1>Add New Certificate</h1>
                    <form action="certificate_add.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Certificate Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Certificate ID*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="cert_id" value="<?php if (isset($_POST['cert_id'])) echo $_POST['cert_id'];?>" data-error="Please enter the certificate id" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Certificate Name*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="cert_name" value="<?php if (isset($_POST['cert_name'])) echo $_POST['cert_name'];?>" data-error="Please enter the certificate name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Certificates's Program*</label>
                            <div class="col-xs-2">
                                <select class="form-control" name="prg_name" value="<?php if (isset($_POST['prg_name'])) echo $_POST['prg_name'];?>" data-error="Please enter the certificate's program" required>
                                    <option disabled selected value>---</option>
                                        <?php
                                            require( 'includes/connect_db_c9.php' ) ;
                                            $query = 'SELECT PRG_NAME FROM PROGRAM';
        	                                $results = mysqli_query($dbc, $query);
        	                                if($results){
        	                                    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
                                        		{
                                        			echo '<option>' .  " " . $row['PRG_NAME'] . '</option>' ;
                                        		}
        	                                }
        	                                else
                                        	{
                                        		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
                                        	}
                                        	# Free up the results in memory
                                        	mysqli_free_result( $results );
                                        	mysqli_close( $dbc ) ;
                                        ?>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button class="btn btn-default btn-sm" onclick ="location.href='certificate.php';">Back</button>
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
		</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Bootstrap Form Validator -->
    <script src="js/validator.js"></script>

</body>

</html>
