<?php 
$title = 'IDCP - Course';
require('includes/header.php');
if (isset($_SESSION['stu_id']) && !empty($_SESSION['stu_id'])) {
    session_destroy();
} 
?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <div class="page-header">
                        <h1>Courses</h1>
                    </div>
                    <br>
                    <div class = "butspan" style = "width: 300px;">
                        <button type="button" class="btn btn-primary btn-block" style = "margin-right: 50px; height: 50px;" onclick="location.href='add_course.php';">Add New Course</button>
                        <button type="button" class="btn btn-primary btn-block" style = "margin-right: 50px; height: 50px;" onclick="location.href='course_search.php';">Search for Course</button>
                    </div>
                    <br>
                    <button class="btn btn-default btn-sm" onclick ="location.href='home.php';">Back</button>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
