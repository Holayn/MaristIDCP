<?php
session_start();
$_SESSION['CRS_ID'] = $_POST['CRS_ID'];
$_SESSION['CRS_ENROLL_YR'] = $_POST['CRS_ENROLL_YR'];
# Converts month name to its number
$monthname = $_POST['CRS_ENROLL_MON'];
if($monthname == January){
    $monthname = 1;
}
if($monthname == "February"){
    $monthname = 2;
}
if($monthname == "March"){
    $monthname = 3;
}
if($monthname == "April"){
    $monthname = 4;
}
if($monthname == "May"){
    $monthname = 5;
}
if($monthname == "June"){
    $monthname = 6;
}
if($monthname == "July"){
    $monthname = 7;
}
if($monthname == "August"){
    $monthname = 8;
}
if($monthname == "September"){
    $monthname = 9;
}
if($monthname == "October"){
    $monthname = 10;
}
if($monthname == "November"){
    $monthname = 11;
}
if($monthname == "December"){
    $monthname = 12;
}
$_SESSION['CRS_ENROLL_MON'] = $monthname;
$_SESSION['CRS_ENROLL_DAY'] = $_POST['CRS_ENROLL_DAY'];
//Close any existing db connections
mysqli_close( $dbc ) ;
?>