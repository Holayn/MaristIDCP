<?php
  require( 'includes/connect_db_c9.php' ) ; 

$debug = true;
function insert_course($dbc, $crs_id, $crs_name, $crs_level) {
  $query = 'INSERT INTO COURSE(CRS_ID, CRS_NAME, CRS_LEVEL) VALUES ("'.$crs_id.'" , "'.$crs_name.'" , "'.$crs_level.'")' ;
 //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function update_course($dbc, $crs_id, $crs_name, $crs_level) {
  $query = 'UPDATE COURSE SET CRS_NAME = "'.$crs_name.'", CRS_LEVEL = "'.$crs_level.'" WHERE CRS_ID = "'.$crs_id.'"';
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function insert_course_program($dbc, $crs_id, $prg_id){
  $query = 'INSERT INTO CRS_MADE_OF (CRS_ID, PRG_ID) VALUES ("'.$crs_id.'" , "'.$prg_id.'")'; 
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function get_prg_id($dbc, $prg_name){
  $query = 'SELECT PRG_ID FROM PROGRAM WHERE PRG_NAME = "'.$prg_name.'"'; 
  //show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if(!$results){
    	echo "didnt work";
    }
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$prg_id = $row ['PRG_ID'];
	return $prg_id;
}


function show_brief_course_results($dbc, $string){
	$query = "SELECT CRS_ID, CRS_NAME, CRS_LEVEL FROM COURSE WHERE CRS_ID LIKE '%$string%' OR CRS_NAME LIKE '%$string%'";
	// show_query($query);
	$results = mysqli_query($dbc, $query);
	echo '<div class="span3" style="height: 200px !important; overflow: auto;">';
	echo '<TABLE class="table table-condensed table-striped table-hover">';
	echo '<THEAD>';
	echo '<TR>';
	echo '<TH>ID</TH>';
	echo '<TH>Name</TH>';
	echo '<TH>Level</TH>';
	echo '</TR>';
	echo '</THEAD>';
	echo '<TBODY>';
	if($results){
		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ){
			echo "<TR class='clickable-row'>";
			echo '<TD>' . $row['CRS_ID'] . '</TD>' ;
			echo '<TD>' . $row['CRS_NAME'] . '</TD>' ;
			echo '<TD>' . $row['CRS_LEVEL'] . '</TD>' ;
			echo '</TR>';
		}
		echo '</TBODY>';
		echo '</TABLE>';
    }
  echo '</div>';
	# Free up the results in memory
	mysqli_free_result( $results );
	mysqli_close( $dbc ) ;
}

function get_crs_name($dbc, $crs_id){
  require( 'includes/connect_db_c9.php' ) ; 
	$query = "SELECT CRS_NAME FROM COURSE WHERE CRS_ID = '$crs_id'";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if(!$results){
    	echo "didnt work";
    }
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$crs_name = $row ['CRS_NAME'];
	return $crs_name;
}

function get_crs_level($dbc, $crs_id){
  require( 'includes/connect_db_c9.php' ) ; 
	$query = "SELECT CRS_LEVEL FROM COURSE WHERE CRS_ID = '$crs_id'";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if(!$results){
    	echo "didnt work";
    }
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$crs_level = $row ['CRS_LEVEL'];
	return $crs_level;
}

function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}


?>