(X) = Done
(!!!) = Attention

Stuff I ran into:
If you are getting a mysqli error, make sure the connection to the DB is open! Sometimes a function closes it. Also, make sure you close the DB connection when redirecting to another page.
Getting rid of bottom scrollbar:**
Replace page content div container with:
<div class="container-fluid">
Also make titles headers with <div class="page-header">
-------------------------------------------------------------------

C9 DB CHANGES:
	I moved STU_QUALIFY_EXAM to PRG_ENROLLED, away from STUDENT. Makes more sense this way if student is in more than one program.
	Changed PRG_ENROLLED's ENROLL_STATUS to PRG_ENROLL_STATUS to match server database
	Changed EMP_ID to AUTO_INCREMENT. also had to define EMP_ID as primary in table definition rather than after because of AUTO_INCREMENT.
	Made enroll dates primary key in prg_enrolled, just like crs_enrolled
	Changed stu_transcript to store string
	Changed stu_citizen to store string
	Changed stu_qualify_exam to store string
	Changed credit to store string
	Made IDCP_USER one table and added role column (not changed on server yet)

Wendy Changelog:
	I made this change to the actual database too
	STU_PHONE IS NOW VARCHAR(20) since international numbers are included
	STU_TRANSCRIPT IS NOW VARCHAR(20) it can be high school, college, none
	Certificate pages are done, can search, view, add, and edit
	Changed primary key of CRS_ENROLLED to crs_id, stu_id, and the enroll date in sql file and database
	Updated sidebars of all pages to go to certificate.php when certificate is clicked
	Server database fake data uploaded
	Server database table structures match idcp.sql (CRS_ENROLLED PK = CRS + STU + DATE, PRG_ENROLLED PK = PRG + STU +DATE, EMP_ID = AUTO_INCREMENT)
	Testing filter functions with student page in student_search.1.php'

What Wendy working on:
	User login pages
		

Christian Changelog:
	Added option to add courses from the edit student course home page
	Added option to add programs from the edit student program home page
	Updated all pages to include the new sidebar
	Added the dynamic search table to course searches
	Added option for course's program when adding a new course, inserts into CRS_MADE_OF

What Christian working on:
	Program pages
	Student profile - certificates functionality. Edit student certificate information, add student certificate information.
	Give way to delete certificate, student, etc
	

Kai Changelog:
	Finished add student
	Finished edit student
	Finished adding student's courses and programs
	Finished edit and view student's courses and programs and information (profile)
	Improved search page
	Made student profile detail page less pretty and more straightforward
	When user reloads page, keeps what they input in form (for student page)
	Error is thrown when user tries to enter duplicate student id
	Made add employer button on add student page functional
	3/28---
	Since dates are primary keys now, made change to how things work on edit-student-courses-home
	Since dates are primary key now, made change to how things work program edit student
	CREATED HEADER.PHP FILE! See index.php and student.php to see how to apply them to each file. So we don't need to change navbars across all pages.
	Updated all pages to require header.php!
	Added back buttons to course pages, updated course profile page and edit course page (added validator)
	Edit course_profile.php to match student_profile functionality
	Renamed all pages and links to pages (it was just a find and replace in cloud9)

What Kai working on: 
	put reload sticky on other pages. like add_student_program
	Get rid of decoration (e.g. student detail profile) Simple and straightforward (X)
	Add edit stu course needs to pull from db to populate form with existing values
	Add back buttons, increase interface transparency in additional ways
	Report page


TO DO:
Help pages
Rename pages to not have zOS, and make sure all pages referenced in code are updated accordingly
Make newindex.html the new index.html. Update sidebars (we need to agree on new design first)
Import data to database. Done by importing data into a big table, and inserting with select (x)
Make user settings page [WENDY: working on it]
Make IDCP settings page. Be able to add employers and instructors here
Add Programs to the sidebar and all of its necessary parts
Add Certificates to the sidebar and all of its necessary parts (x)
Be able to add an employer from add student page
Be able to add courses in the Edit Student Courses page on student profile page
Be able to add programs in the Edit Student Programs page on student profile page
Add View/Edit pages for Student Certificates on student profile page (same like add courses/programs) (x)
When adding courses, be able to select what program the course is part of. Same when editing courses
Add breadcrumbs where it makes sense (https://www.tutorialspoint.com/bootstrap/bootstrap_breadcrumb.htm)
Escape_string all inputs (sanitizing) and improve data input validation
Change all instances of $_SESSION['stu_id'] to $_SESSION['STU_ID'] on pages that have broken PHP.
Maybe put header into its own file and include it on every page. That way don't have to change header on every page. (x)
Should store stu_transcript as string itself, not random 0, 1, 2. Random person looking at DB will not know what it means. Same with stu_qualify_exam in prg_enrolled.
DOes stu_qualify_exam actually belong in cert_enrolled?

Helpful Links:
http://getbootstrap.com/components/

Make sure to reference back to our ER diagram. [WENDY: i will upload the updated version to google docs, minor changes]

Make tables scrollable by surrounding table with <div class="span3" style="height: 200px !important; overflow: auto;"> 



---------Kai's Old Notes--------

(!!!!!!!!!!!!)
Rename pages to not have zOS. That way, it's easier to duplicate for Data Center. MB guys -Kai
Our best bet is to have a folder named zOS and another folder named Data Center.
(!!!!!!!!!!!!see below big attention!!!)

Importing data to database  [Wendy's working on it]
Import data into big fake table, insert select.  [Wendy's working on it]

UPDATE SIDEBAR TO REFLECT NEW CHANGES, AS WELL AS INDEX.html. REPLACE zOS.php with index.html. Look at newindex.html

If there is error in DB, say they try to add in a tag that already exists for another student, then how to provide feedback?

(!!!!!!!!!!!!!!!!!!!!!!!!!big attention!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!)
student_profile_detail - what if student is enrolled in multiple programs? should we just make it one form, and no separate Data Center and z/OS?
e.g. if they want to add a Data Center student, but student is already a z/OS student, they won't be able to add the student. How to fix this?
Right now, I will show as much program information that they have in the detail page. Show all programs they're in dynamically and their info. (X)
On add student page, provide way to add what program(s) they are in. (X - made it a separate page like courses)
Program status (X)

OR include an option to add an existing student to a program (button on students page)?
Maybe we should scrap the separate program pages. Have a master student, courses, reports. When adding student, put what program(s) they are taking. Separate page, like when adding courses. be able to edit this. (X)
Same thing with adding courses. Have option to select what program it is part of
Put qualifying exam with prg_enrolled, not student. (X)
Separate student's courses by what program the courses correspond to. Actually, just make the table show what program they want to see for. easy with query
(!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!)


Be able to add courses to edit course page. e.g. student id of 103. Yolo Swag has no classes rn, be able to add courses from his profile page, in courses view.
Be able to add programs to edit programs page. same as courses above.
When adding a new course, make sure to also add a new record to CRS_MADE_OF! Otherwise, course isn't associated with a program. Also be able to edit what program course is part of.

Be able to change student's status in program - Active, Complete, Dropped, Failed

Edit student info (X)
and courses they're taking (x)

error checking on add student form (X)
error checking on add course for student (X)
seeing detail info for student (X)
separate inactive, active courses (X)
list 3 recent active courses (X)

put courses for student on add course page (X)
be able to add course from add course for student page, and go back to where you were before (this will be a lot of work. need to save user progress on that page. there could be problems if there are fields not set. maybe don't bother with this)
make them able to add an employer from add student screen (this will be a lot of work. need to save user progress on that page. there could be problems if there are fields not set.)

make user settings page
make IDCP settings page (top right)
	add employers
	add instructors

be able to search for students by name (who memorizes/searches by IDs?) (X)
display some students/courses in table when searching, or just give the whole list of students (!!!) (X)
display current courses for student (X)

add success pages (for ones that aren't obvious) (X mostly)
add edit student's courses page (X)

get current year (X)

breadcrumbs: https://www.tutorialspoint.com/bootstrap/bootstrap_breadcrumb.htm (we should def put this in)
pagination: https://www.tutorialspoint.com/bootstrap/bootstrap_pagination.htm (meh)
cool tricks: https://scotch.io/bar-talk/bootstrap-3-tips-and-tricks-you-might-not-know#how-to-enable-bootstrap-3-hover-dropdowns
Jquery and php: http://stackoverflow.com/questions/607673/setting-a-php-sessionvar-using-jquery

http://getbootstrap.com/components/