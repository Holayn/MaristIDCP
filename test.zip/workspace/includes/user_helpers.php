<?php
$debug = true;

# Adds a new user to a database
function add_new_user_record($dbc, $user_id, $user_name, $user_pwd, $user_role) {
  require( 'includes/connect_db_c9.php' ) ; 
  $user_pwd = SHA1($user_pwd);
  $query = "INSERT INTO IDCP_USER(USER_ID, USER_NAME, USER_PWD, USER_ROLE) VALUES(".$user_id.", '".$user_name."','".$user_pwd."', '".$user_role."')";
  //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  return $results ;
}

function update_user_record($dbc, $user_id, $user_name, $user_role){
  require( 'includes/connect_db_c9.php' ) ; 
  $query = "UPDATE IDCP_USER SET USER_NAME='".$user_name."', USER_ROLE='".$user_role."' WHERE USER_ID = $user_id";
  //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  return $results ;
}

function update_user_password($dbc, $user_id, $user_pwd_new){
  require( 'includes/connect_db_c9.php' ) ; 
  $user_pwd_new = SHA1($user_pwd_new);
  $query = "UPDATE IDCP_USER SET USER_PWD='".$user_pwd_new."' WHERE USER_ID = $user_id";
  //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  return $results ;
}

function get_user_role($dbc, $user_id){
  require( 'includes/connect_db_c9.php' ) ; 
  $query = "SELECT USER_ROLE FROM IDCP_USER WHERE USER_ID = $user_id";
 // show_query($query);
  $results = mysqli_query($dbc,$query);
  if ($results){
    $row = mysqli_fetch_array( $results , MYSQLI_ASSOC );
    return $row['USER_ROLE'];
  }
    else{
    		echo $user_id;
    }
    mysqli_free_result( $results );
		mysqli_close( $dbc ) ;
}

function get_user_name($dbc, $user_id){
  require( 'includes/connect_db_c9.php' ) ; 
  $query = "SELECT USER_NAME FROM IDCP_USER WHERE USER_ID = $user_id";
  //show_query($query);
  $results = mysqli_query($dbc,$query);
  if ($results){
    $row = mysqli_fetch_array( $results , MYSQLI_ASSOC );
    return $row['USER_NAME'];
  }
    else{
    		echo $user_id;
    }
    mysqli_free_result( $results );
		mysqli_close( $dbc ) ;
}

?>