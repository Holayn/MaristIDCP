<?php
  require( 'includes/connect_db_c9.php' ) ; 

$debug = true;
function insert_employer($dbc, $emp_name, $emp_email, $emp_phone){
	$query = 'INSERT INTO EMPLOYER(EMP_NAME, EMP_EMAIL, EMP_PHONE) VALUES ("'.$emp_name.'" , "'.$emp_email.'", "'.$emp_phone.'")';
 //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}


?>