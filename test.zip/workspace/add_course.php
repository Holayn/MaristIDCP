<?php
    $title = "IDCP - Add Course";
    require('includes/header.php');
    # Connect to MySQL server and the database
    require( 'includes/connect_db_c9.php' ) ;
    # Includes these helper functions
    require( 'includes/course_helpers.php' ) ;
    # Check to make sure it is the first time user is visiting the page
    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    	$crs_id = "";
    	$crs_name = "";
    	$crs_level = "";
    }
    # Check to make sure the form method is post
    if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    	$crs_id = $_POST['crs_id'];
    	$crs_name = $_POST['crs_name'];
    	$crs_level = $_POST['crs_lvl'];
		$crs_id = trim($crs_id);
		$crs_name = trim($crs_name);
		$crs_level = trim($crs_level);
		$result = insert_course($dbc, $crs_id, $crs_name, $crs_level);
		
		$prg_name = $_POST['prg_name'];
		trim($prg_name);
		$prg_id = get_prg_id($dbc, $prg_name);
		insert_course_program($dbc, $crs_id, $prg_id);
		$page = 'add_course_success.php';
		header("Location: $page");
		
		
    }
     mysqli_close( $dbc ) ;
?>
<style>
.button {
    background-color: darkred;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container" style="padding-right: 100px; max-width: 1100px;">
                <div class="dropdown">
                    <h1>z/OS Add a Course</h1>
                    <form action="add_course.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Course Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course ID*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_id" value="<?php if (isset($_POST['crs_id'])) echo $_POST['crs_id'];?>" data-error="Please enter the course id" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course Name*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_name" value="<?php if (isset($_POST['crs_name'])) echo $_POST['crs_name'];?>" data-error="Please enter the course name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course Level*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_lvl" value="<?php if (isset($_POST['crs_lvl'])) echo $_POST['crs_lvl'];?>" data-error="Please enter the course level" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course's Program*</label>
                            <div class="col-xs-2">
                                <select class="form-control" name="prg_name" value="<?php if (isset($_POST['crs_lvl'])) echo $_POST['crs_lvl'];?>" data-error="Please enter the course's program" required>
                                    <option disabled selected value></option>
                                        <?php
                                            require( 'includes/connect_db_c9.php' ) ;
                                            $query = 'SELECT PRG_ID, PRG_NAME FROM PROGRAM';
        	                                $results = mysqli_query($dbc, $query);
        	                                if($results){
        	                                    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
                                        		{
                                        			echo '<option>' .  " " . $row['PRG_NAME'] . '</option>' ;
                                        		}
        	                                }
        	                                else
                                        	{
                                        		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
                                        	}
                                        	# Free up the results in memory
                                        	mysqli_free_result( $results );
                                        	mysqli_close( $dbc ) ;
                                        ?>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <!-- ADD WHAT PROGRAM COURSE IS PART OF. Populate dropdown from DB -->
                        
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button class="btn btn-default btn-sm" type="button" onclick ="location.href='course.php';">Back</button>
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
		</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Bootstrap Form Validator -->
    <script src="js/validator.js"></script>

</body>

</html>
