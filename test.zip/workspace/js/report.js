function displayFields() {
	document.getElementById('prg_display').style.display = 'none';
	document.getElementById('crs_display').style.display = 'none';
	document.getElementById('ins_display').style.display = 'none';
	document.getElementById('stu_display').style.display = 'none';
	document.getElementById('cert_display').style.display = 'none';
	document.getElementById('emp_display').style.display = 'none';
	document.getElementById('prg_specs').style.display = 'none';
	
	alert("changed");
	var x = document.getElementById('entity1').value;
	alert(x+" is selected");
	if(x == "program") {
		alert("program");
		document.getElementById('prg_display').style.display = 'inline';
	}
	else if(x == "course") {
		alert("course");
		document.getElementById('crs_display').style.display = 'inline';
	}
	else if(x == "instructor") {
		alert("instructor");
		document.getElementById('ins_display').style.display = 'inline';
	}
	else if(x == "student") {
		alert("student");
		document.getElementById('stu_display').style.display = 'inline';
	}
	else if(x == "certificate") {
		alert("certificate");
		document.getElementById('cert_display').style.display = 'inline';
	}
	else if(x == "employer") {
		alert("employer");
		document.getElementById('emp_display').style.display = 'inline';
	}
	else {
		alert("missing value");
	}
}
function displaySpecs() {

	   document.getElementById('prg_specs').style.display = 'inline';
}

