<?php
    $title = "IDCP - Add Program";
    require('includes/header.php');
    # Connect to MySQL server and the database
    require( 'includes/connect_db_c9.php' ) ;
    # Includes these helper functions
    require( 'includes/program_helpers.php' ) ;
    # Check to make sure it is the first time user is visiting the page
    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    	$prg_id = "";
    	$prg_name = "";
    }
    # Check to make sure the form method is post
    if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    	$prg_id = $_POST['prg_id'];
    	$prg_name = $_POST['prg_name'];
		$prg_id = trim($prg_id);
		$prg_name = trim($prg_name);
		$result = insert_program($dbc, $prg_id, $prg_name, $prg_level);
		
		$page = 'add_program_success.php';
		header("Location: $page");
	
		
    }
     mysqli_close( $dbc ) ;
?>
<style>
.button {
    background-color: darkred;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container" style="padding-right: 100px; max-width: 1100px;">
                <div class="dropdown">
                    <h1>z/OS Add a Program</h1>
                    <form action="add_program.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Program Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Program ID*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="prg_id" value="<?php if (isset($_POST['prg_id'])) echo $_POST['prg_id'];?>" data-error="Please enter the program id" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Program Name*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="prg_name" value="<?php if (isset($_POST['prg_name'])) echo $_POST['prg_name'];?>" data-error="Please enter the program name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        
                        <!-- ADD WHAT PROGRAM COURSE IS PART OF. Populate dropdown from DB -->
                        
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button class="btn btn-default btn-sm" type="button" onclick ="location.href='program.php';">Back</button>
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
		</div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Bootstrap Form Validator -->
    <script src="js/validator.js"></script>

</body>

</html>
