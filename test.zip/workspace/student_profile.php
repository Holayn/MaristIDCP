
<?php 
    $title = "IDCP - Student Profile";
    require('includes/header.php');
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/student_helpers.php' ) ;
    $stu_id = $_SESSION['STU_ID'];
    $_SESSION['searchString'] = "";
?>
<script>
    sessionStorage.clear();
</script>

<style>
    .inline {
  display: inline;
}

.link-button {
  background: none;
  border: none;

}
.link-button:focus {
  outline: none;


}

.link-button:hover {
  outline: none;
  

}
.link-button:active {
  color:white;
}
</style>
        <!-- Page Content -->
        <?php
        # Connect to MySQL server and the database
        require( 'includes/report_helpers.php' ) ;
        ?>
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1000px;">-->
                <div class="page-header">
                    <h1>
                        <?php
                            echo get_stu_name($dbc, $stu_id);
                        ?>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    <!--<form method="get" action="edit_student.php" class="inline">-->
                                    <!--  <input type="hidden" name="student_ID" value="<?php //echo $stu_id; ?>">-->
                                    <!--    <button type="submit" class="link-button">-->
                                    <!--        Edit Student Info-->
                                    <!--    </button>-->
                                    <!--  </form>-->
                                    <!--<a href="edit_student.php">Student Info</a>-->
                                    Personal Info
                                </h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <p><label>ID</label><br>
                                        <?php
    				                        echo $stu_id;                                
    				                    ?>
				                    </p>
                                    <p><label>Gender</label><br>
                                        <?php
                                         echo get_stu_gender($dbc, $stu_id);
                                        ?>
                                    </p>
                                    <p><label>Student Since</label><br>
                                        <?php
                                         echo month_num_to_name(get_stu_mon_start($dbc, $stu_id));
                                         echo " ";
                                         echo get_stu_day_start($dbc, $stu_id);
                                         echo ", ";
                                         echo get_stu_yr_start($dbc, $stu_id);
                                        ?>
                                    </p>
                                    <button class="btn btn-default btn-sm" onclick="location.href='student_profile_detail.php';">View More</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='edit_student.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Courses</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <?php
                                        show_recent_student_courses($dbc, $stu_id);
                                    ?>
                                <button class="btn btn-default btn-sm" onclick="location.href='edit_student_courses_home.php';">View More</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='edit_student_courses_home.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Programs</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <?php
                                        show_student_programs($dbc, $stu_id);
                                    ?>
                                <button class="btn btn-default btn-sm" onclick="location.href='edit_student_program_home.php';">View More</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='edit_student_program_home.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Certificates</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <?php
                                    $id=20034567;
                                    show_stu_cert($dbc,$id);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <button class="btn btn-default btn-sm" onclick="location.href='student_search.php';">Back to Search</button>
                    </div>
                </div>
            <!-- /#container close -->
            </div>
        <!-- /#page-content-wrapper -->
        </div>
    </div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>
