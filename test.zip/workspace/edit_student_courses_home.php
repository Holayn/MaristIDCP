    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<?php
        $title = "IDCP - Edit Student's Courses";
        require('includes/header.php');
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/student_helpers.php' ) ;
        $stu_id = $_SESSION['STU_ID'];
        # Check to make sure it is the first time user is visiting the page
    //     if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    //     // 	$query = "SELECT * FROM STUDENT WHERE STU_ID = $stu_id";
    //     // 	$result = mysqli_query($dbc, $query);
    //     // 	$row = mysqli_fetch_array($result, MYSQLI_ASSOC) ;
    //     // 	$stu_id = $row['STU_ID'];
    //     	}
    //     else{
    //         echo '<p>'.mysqli_error($dbc).'</p>';
    //     }
    //     # Check to make sure the form method is post
    //     if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
    //     	$stu_id = $_POST['stu_id'];
    // 		#Inserts inputs into table if all inputs are valid
    // 		$stu_fname = trim($stu_fname);
    // 		//$result = insert_record($dbc, $stu_id, $stu_tag, $stu_lname, $stu_fname, $stu_initial, $stu_yr_start, $stu_mon_start, $stu_day_start, $stu_edu_lvl, $stu_job_title, $stu_street, $stu_city, $stu_state, $stu_country, $stu_zip, $stu_phone, $stu_email_1, $stu_email_2, $stu_yr_dob, $stu_mon_dob, $stu_day_dob, $stu_ethnicity, $stu_gender, $stu_citizen, $stu_transcript, $stu_qualify_exam, $stu_comment, $emp_id);
    // 		echo "Success! Thanks"; 
    // 		$page = 'student_profile.php';
    //         header("Location: $page");
    //     }
    //     //If the user clicks on a link, the GET method will be returned, so run this else-if block to show the user more information about the president
    //     else if($_SERVER['REQUEST_METHOD'] == 'GET'){
    //     	if(isset($_GET['id']))
    //     		show_record($dbc, $_GET['id']);
    //     }
    //     # Show the records
    //     //show_link_records($dbc);
    //     # Close the connection
    //     mysqli_close( $dbc ) ;
        
        ?>
        <!-- Page Content -->
        <div id="page-content-wrapper" style="margin-left: 50px;">
            <!--<div class="container" style="padding-right: 100px; max-width: 1000px;">-->
            <div class="container-fluid">
                <div class="dropdown">
                    <div class="row">
                        <div class="page-header">
                            <?php
        				        $stu_id = $_SESSION['STU_ID'];
        				        $name = get_stu_name($dbc, $stu_id);
        				        echo '<h1>Courses for ' . "$name" . '   <small>Click a row to edit</small></h1>';
    				        ?>
                        </div>
                    </div>
                    <div class="row">
                        <h3>Active Courses</h3>
                    </div>
                    <!--List the student's active courses-->
                    <div class="row">
                    <?php
                        show_active_courses($dbc, $stu_id); 
                    ?>
                    </div>
                    <div class="row">
                        <h3>Completed Courses</h3>
                    </div>
                    <!--List the student's completed courses-->
                    <div class="row">
                    <?php
                        show_completed_courses($dbc, $stu_id); 
                    ?>
                    </div>
                    <div class="row">
                        <h3>Inactive Courses</h3>
                    </div>
                    <!--List the student's completed courses-->
                    <div class="row">
                    <?php
                        show_inactive_courses($dbc, $stu_id); 
                    ?>
                    </div>
                    <!--<form action="edit_student.php" method="POST" class="form-horizontal" data-toggle="validator" id="student_form">-->
                        
                        <!--<div class="form-group">-->
                        <!--    <div class="col-xs-5 col-xs-offset-3">-->
                        <!--        <button type="submit" class="btn btn-default">Submit</button>-->
                        <!--    </div>-->
                        <!--</div>-->
                    <!--</form>-->
                    <div class="row">
                        <div class = "butspan" style = "width: 300px;">
                            <button class="btn btn-default" onclick ="location.href='student_profile.php';">Back</button>
                            <button class="btn btn-default" onclick ="location.href='add_edit_student_course.php';">Add a Course</button>
                        </div>
                        
                        
                        
                    </div>
                    
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
    </div>
    <!-- /#wrapper -->

    <!--<script type="text/javascript" src="js/jquery.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>
    
    <!--Makes table rows clickable-->
    <script>
    jQuery(document).ready(function($) {
        $('.table > tbody > tr').click(function() {
            // //Puts CRS_ID into session
            // var value = $(this).find('td:first').text(); //first column in table
            // // Send Ajax request to backend.php, with value set as "CRS_ID" in the POST data
            // $.post("/backendstu.php", {"STU_ID": value});
            // window.location.href = "student_profile.php";
            
            var crsid = $(this).find('td:first').text();
            var enrollyr = $(this).find('td:nth-child(2)').text();
            var enrollmon = $(this).find('td:nth-child(3)').text();
            var enrollday = $(this).find('td:nth-child(4)').text();
            jQuery.ajax({
                url: 'backendcrs.php',
                type: 'POST',
                data: {
                    'CRS_ID': crsid,
                    'CRS_ENROLL_YR': enrollyr,
                    'CRS_ENROLL_MON': enrollmon,
                    'CRS_ENROLL_DAY': enrollday,
                },
                dataType : 'json',
                success: function(data, textStatus, xhr) {
                    window.location.href = "edit_student_course.php";
                    console.log(data); // do with data e.g success message
                },
                error: function(xhr, textStatus, errorThrown) {
                    console.log(textStatus.reponseText);
                    window.location.href = "edit_student_course.php";
                }
            });
        });
    });
    </script>
    <script>
    //     $('.table > tbody > tr').click(function() {
    //         //Puts CRS_ID into session
    //         var value = $(this).find('td:first').text();
    //         // Send Ajax request to backend.php, with value set as "CRS_ID" in the POST data
    //         $.post("/backendcrs.php", {"CRS_ID": value});
    //         window.location.href = "edit_student_course.php";
    //     });
        
    </script>
    
    <script>
        // window.onload = function() {
        //     if (window.jQuery) {  
        //         // jQuery is loaded  
        //         alert("Yeah!");
        //     } else {
        //         // jQuery is not loaded
        //         alert("Doesn't Work");
        //     }
        // }
    </script>
    

</body>

</html>
