<?php
$title = "IDCP - Edit Program";
require('includes/header.php');
$prg_id = $_SESSION['PRG_ID'];
        require( 'includes/connect_db_c9.php' ) ;
        require( 'includes/program_helpers.php' ) ;
   

    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        	$prg_id = "";
        	$prg_name = "";
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
        	$prg_id = $_SESSION['PRG_ID'];
        	$prg_name = $_POST['prg_name'];

        	$prg_name = trim($prg_name);

        	$result = update_program($dbc, $prg_id, $prg_name);
        	$page = 'program_profile.php';
            header("Location: $page");
        }
?>
<style>
.button {
    background-color: darkred;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="dropdown">
                    <h1>Edit Program Information for <?php $prg_id = $_SESSION['PRG_ID']; echo get_prg_name($dbc, $prg_id);?></h1>
                    <!--<form action ="edit_program.php?program_ID=<?php echo $prg_id?>" method="POST" class="form-horizontal">-->
                    <form action ="edit_program.php" method="POST" class="form-horizontal" data-toggle="validator" id="edit_program_form">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Program Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Program ID</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="prg_id" value="<?php echo $prg_id;?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Program Name</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="prg_name" value="<?php echo get_prg_name($dbc, $prg_id);?>" data-error="Please enter a program name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="button" class="btn btn-default" onclick ="location.href='program_profile.php';">Back</button>
                                <button type="submit" class="btn btn-default">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
     <!--Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>


</body>

</html>
