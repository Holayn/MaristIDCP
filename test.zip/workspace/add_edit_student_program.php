<!--Allows user to add course for student -->
<?php
        $title = 'IDCP - Add Program for Student';
        require('includes/header.php');
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/student_helpers.php' ) ;
        # Check to make sure it is the first time user is visiting the page
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            $prg_name = "";
            $prg_enroll_yr_start = "";
            $prg_enroll_mon_start = "";
            $prg_enroll_day_start = "";
            $credit = "";
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
            $prg_id = $_POST['prg_name'];
            $prg_enroll_yr_start = $_POST['prg_enroll_yr_start'];
            $prg_enroll_mon_start = $_POST['prg_enroll_mon_start'];
            $prg_enroll_day_start = $_POST['prg_enroll_day_start'];
            $prg_enroll_mon_start = month_name_to_num($prg_enroll_mon_start);
            $stu_qualify_exam = $_POST['stu_qualify_exam'];
        	$query = "SELECT PRG_ID FROM PROGRAM WHERE PRG_NAME = '$prg_id'";
        	$results = mysqli_query($dbc, $query);
        	$row = mysqli_fetch_array( $results , MYSQLI_ASSOC );
            $prg_id = $row['PRG_ID'];
            $stu_id = $_SESSION['STU_ID'];
    		$result = add_new_prg_enrolled_record($dbc, $stu_id, $prg_id, $prg_enroll_day_start, $prg_enroll_mon_start, $prg_enroll_yr_start, $stu_qualify_exam);
    		echo "Success! Thanks" ; 
    		$_SESSION['addedProgram'] = true;
    		$page = 'edit_student_program_home.php';
            header("Location: $page");
        }
        # Close the connection
        mysqli_close( $dbc ) ;
        ?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="dropdown">
                    <div class="page-header">
                        <!--Make this dynamic-->
                        <?php
    				        $stu_id = $_SESSION['STU_ID'];
    				        $name = get_stu_name($dbc, $stu_id);
    				        echo '<h1>Add a Program for ' . "$name" . '</h1>';
    				    ?>
				    </div>
                    <form action="add_edit_student_program.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Program Information</h3>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Program*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="prg_name" value="<?php if (isset($_POST['prg_name'])) echo $_POST['prg_name'];?>" data-error="Please select a program" required>
                                <option disabled selected value>-- select an option --</option>
                                <?php
                                    require('includes/connect_db_c9.php');
                                    $query = 'SELECT PRG_NAME FROM PROGRAM';
	                                $results = mysqli_query($dbc, $query);
	                                if($results){
	                                    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
                                		{
                                			echo '<option>' . $row['PRG_NAME'] . '</option>' ;
                                		}
	                                }
	                                else
                                	{
                                		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
                                	}
                                	# Free up the results in memory
                                	mysqli_free_result( $results );
                                	mysqli_close( $dbc ) ;
                                ?>
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Year*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="prg_enroll_yr_start" value="<?php if (isset($_POST['prg_enroll_yr_start'])) echo $_POST['prg_enroll_yr_start'];?>" data-error="Please select the student's start year" required>
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $prg_enroll_yr_start;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Month*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="prg_enroll_mon_start" value="<?php if (isset($_POST['prg_enroll_mon_start'])) echo $_POST['prg_enroll_mon_start'];?>" data-error="Please select the student's start month" required>
                                    <option disabled selected value>--</option>
                                    <option>January</option>
                                    <option>February</option>
                                    <option>March</option>
                                    <option>April</option>
                                    <option>May</option>
                                    <option>June</option>
                                    <option>July</option>
                                    <option>August</option>
                                    <option>September</option>
                                    <option>October</option>
                                    <option>November</option>
                                    <option>December</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Day*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="prg_enroll_day_start" value="<?php if (isset($_POST['prg_enroll_day_start'])) echo $_POST['prg_enroll_day_start'];?>" data-error="Please select the student's start day" required>
                                    <option disabled selected value>--</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                    <option>16</option>
                                    <option>17</option>
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Qualifying Exam*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_qualify_exam" value="<?php if (isset($_POST['stu_qualify_exam'])) echo $_POST['stu_qualify_exam'];?>" data-error="Please select if the student has passed a qualifying exam" required>
                                    <option disabled selected value>--</option>
                                    <option>Yes</option>
                                    <option>No</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="button" class="btn btn-default" onclick ="location.href='edit_student_program_home.php';">Back</button>
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>

</body>

</html>
