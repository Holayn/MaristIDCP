<?php
session_start();
$_SESSION['CERT_ID'] = $_POST['CERT_ID'];
//Close any existing db connections
mysqli_close( $dbc ) ;
?>