<?php
session_start();
$_SESSION['PRG_ID'] = $_POST['PRG_ID'];
$_SESSION['PRG_NAME'] = $_POST['PRG_NAME'];
$_SESSION['PRG_ENROLL_YR_START'] = $_POST['PRG_ENROLL_YR_START'];
# Converts month name to its number
$monthname = $_POST['PRG_ENROLL_MON_START'];
if($monthname == January){
    $monthname = 1;
}
if($monthname == "February"){
    $monthname = 2;
}
if($monthname == "March"){
    $monthname = 3;
}
if($monthname == "April"){
    $monthname = 4;
}
if($monthname == "May"){
    $monthname = 5;
}
if($monthname == "June"){
    $monthname = 6;
}
if($monthname == "July"){
    $monthname = 7;
}
if($monthname == "August"){
    $monthname = 8;
}
if($monthname == "September"){
    $monthname = 9;
}
if($monthname == "October"){
    $monthname = 10;
}
if($monthname == "November"){
    $monthname = 11;
}
if($monthname == "December"){
    $monthname = 12;
}
$_SESSION['PRG_ENROLL_MON_START'] = $monthname;
$_SESSION['PRG_ENROLL_DAY_START'] = $_POST['PRG_ENROLL_DAY_START'];
//Close any existing db connections
mysqli_close( $dbc ) ;
?>