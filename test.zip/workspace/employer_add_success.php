<?php
    $title = "IDCP - Add Employer Success";
    require('includes/header.php');
    $page = 'idcp_settings.php';
	header("Refresh: 3;url=$page");
?>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <h1>Success!</h1>
                    <p>You will be automatically redirected in 3 seconds...</p>
                    <div class = "butspan" style = "width: 300px;">
                        <button type="button" class="btn btn-primary btn-block" style = "margin-right: 50px;" onclick="location.href='idcp_settings.php';">Continue</button>
                    </div>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
