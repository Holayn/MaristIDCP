<?php
$title = "IDCP - Edit Course";
require('includes/header.php');
$crs_id = $_SESSION['CRS_ID'];
        require( 'includes/connect_db_c9.php' ) ;
        require( 'includes/course_helpers.php' ) ;
   

    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        	$crs_id = "";
        	$crs_name = "";
        	$crs_level = "";
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
        	$crs_id = $_SESSION['CRS_ID'];
        	$crs_name = $_POST['crs_name'];
        	$crs_level = $_POST['crs_lvl'];
        	
        	$crs_name = trim($crs_name);
        	$crs_level = trim($crs_level);
        	
        	$result = update_course($dbc, $crs_id, $crs_name, $crs_level);
        	$page = 'course_profile.php';
            header("Location: $page");
        }
?>
<style>
.button {
    background-color: darkred;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="dropdown">
                    <h1>Edit Course Information for <?php $crs_id = $_SESSION['CRS_ID']; echo get_crs_name($dbc, $crs_id);?></h1>
                    <!--<form action ="edit_course.php?course_ID=<?php echo $crs_id?>" method="POST" class="form-horizontal">-->
                    <form action ="edit_course.php" method="POST" class="form-horizontal" data-toggle="validator" id="edit_course_form">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Course Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course ID</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_id" value="<?php echo $crs_id;?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course Name</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_name" value="<?php echo get_crs_name($dbc, $crs_id);?>" data-error="Please enter a course name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course Level</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="crs_lvl" value="<?php echo get_crs_level($dbc, $crs_id);?>" data-error="Please enter a course level" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="button" class="btn btn-default" onclick ="location.href='course_profile.php';">Back</button>
                                <button type="submit" class="btn btn-default">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
		    
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
     <!--Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>


</body>

</html>
