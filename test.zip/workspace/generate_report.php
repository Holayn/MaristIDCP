<?php
    $title = "IDCP - Generate a Report";
    require('includes/header.php');
?>
<style>
    .example-print {
        display: none;
    }
    @media print {
       .example-screen {
           display: none;
        }
        .example-print {
           display: block;
        }
    }
</style>

        
    
    <script>
        function showOption(str) {
        document.getElementById('specs_display').style.display = 'inline';
          if (str=="") {
            document.getElementById("specs_display").innerHTML="";
            return;
          } 
          if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
          } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.onreadystatechange=function() {
            if (this.readyState==4 && this.status==200) {
              document.getElementById("specs_display").innerHTML=this.responseText;
            }
          }
          str1 = str + "." + $( "#entity1" ).val();
          xmlhttp.open("GET","backendrptspecific.php?q="+str1,true);
          xmlhttp.send();
        }
        
        function showField(str2) {
            document.getElementById('field_display').style.display = 'inline';
          if (str2=="") {
            document.getElementById("field_display").innerHTML="";
            return;
          } 
          if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
          } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.onreadystatechange=function() {
            if (this.readyState==4 && this.status==200) {
              document.getElementById("field_display").innerHTML=this.responseText;
            }
          }
          //str = $( "#stufield1" ).val();
          xmlhttp.open("GET","backendrptfield.php?p="+str2,true);
          xmlhttp.send();
        }
    </script>

        <!-- Page Content -->
        <?php
            require( 'includes/report_helpers.php' ) ;
        ?>
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="col-lg-6">
                    <div class="page-header">
                        <h1>Generate a Report</h1>
                    </div>
                        <form action="generate_report.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                            <div class="form-group">
                                <label>Generate a report on:</label>
                                    <select class="form-control" id="entity1" name="entity" value="<?php if (isset($_POST['entity'])) echo $_POST['entity'];?>" onchange="showField(this.value)" data-error="Please enter the certificate id" required>
                                        <option disabled selected value>---</option>
                        				<option value="program">Program</option>
                        				<option value="course">Course</option>
                        				<option value="instructor">Instructor</option>
                        				<option value="student">Student</option>
                        				<option value="certificate">Certificate</option>
                        				<option value="employer">Employer</option>
                                    </select>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <div id="field_display" style="display:none">
                    			</div>
                        	    <div class="help-block with-errors"></div>
                            </div>
                        	<div class="form-group">
                        	    <div id="specs_display" style="display:none">
                        	    </div>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" style="margin-right: 50px; height: 50px; width: 300px;">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <div class="table-responsive">
                            <div id="printableArea">
                                <div class="example-print">
                                    <img src="footer_logo.png">
                                    <h2>Report</h2>
                                </div>
                                <table class="table table-hover table-striped">
                            		<?php 
                            			if ($_SERVER['REQUEST_METHOD'] == 'GET'){
                            				$entity = "";
                            				$field = "";
                            				$spec = "";
                            			}
                            			if($_SERVER['REQUEST_METHOD'] == 'POST'){
                            				$entity = strtoupper($_POST['entity']);
                            				$field = $_POST['field'];
                            				$spec = $_POST['spec'];
                            				$statement = 'SELECT * FROM '. $entity.' WHERE '.$field.'= "'.$spec.'"';
                            				show_basic_report($dbc, $statement);
                            			}
                            		?>
                                </table>
                            </div>
                        <?php
                            if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
                                echo '<button type="button" class="btn btn-primary" style="margin-right: 50px; height: 50px; width: 300px;" onclick="printDiv(\'printableArea\')">Print</button>';
                            }
                        ?>
                        <!--<button type="button" class="btn btn-primary" style="margin-right: 50px; height: 50px; width: 300px;" onclick="printDiv('printableArea')">Print</button>-->
                    </div>   
                    </div>
                    <br>
                    <button class="btn btn-default btn-sm" onclick ="location.href='home.php';">Back</button>
                </div>
            <!-- /#container close -->
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

	<script src="js/printhelper.js"></script>
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
