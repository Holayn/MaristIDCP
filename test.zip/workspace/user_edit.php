<?php
        $title = "IDCP - User Edit Info";
        require('includes/header.php');
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/user_helpers.php' ) ;
        $user_id = $_SESSION['user_id'];
        
        # Check to make sure it is the first time user is visiting the page
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        	$query = "SELECT * FROM IDCP_USER WHERE USER_ID = $user_id";
        	$result = mysqli_query($dbc, $query);
        	$row = mysqli_fetch_array($result, MYSQLI_ASSOC) ;
        	$user_id = $row['USER_ID'];
        	$user_name = $row['USER_NAME'];
        	$user_pwd = "";
        	$user_role = $row['USER_ROLE'];
        	mysqli_free_result($result);
        	}
        else{
            echo '<p>'.mysqli_error($dbc).'</p>';
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
        	$user_id = $_POST['user_id'];
        	$user_name = $_POST['user_name'];
        	$_SESSION['user_name'] = $user_name;
        	$user_pwd = SHA1($_POST['user_pwd']);
        	$user_role = $_POST['user_role'];
        	
    		#Updates record if all inputs are valid
    		$query = "SELECT USER_PWD FROM IDCP_USER WHERE USER_ID = $user_id";
        	$result = mysqli_query($dbc, $query);
        	$row = mysqli_fetch_array($result, MYSQLI_ASSOC) ;
        	$user_pwd_data = $row['USER_PWD'];
        	if ($user_pwd != $user_pwd_data){
        	    echo "Wrong password";
        	}
        	else{
            	    $result = update_user_record($dbc, $user_id, $user_name, $user_role);
            	    $page = 'user_settings.php';
                    header("Location: $page");
        	}
        }
    		//echo "Success! Thanks"; 
        # Close the connection
        mysqli_close( $dbc ) ;
        
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="dropdown">
                    <div class="page-header">
                        <?php
    				        //$user_id= $_SESSION['USER_ID'];
    				        echo '<h1>Manage User Account for ' . "$user_name" . '</h1>';
				        ?>
                    </div>
                    <form action="user_edit.php" method="POST" class="form-horizontal" data-toggle="validator" id="user_edit">
                        <div class="form-group">
                            <label class="col-xs-3 control-label">ID*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="user_id" value="<?php if (isset($_POST['user_id'])) echo $_POST['user_id']; else echo $user_id;?>" data-error="Please enter the user's ID" required readonly>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Username*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="user_name" value="<?php if (isset($_POST['user_name'])) echo $_POST['user_name']; else echo $user_name;?>" data-error="Please enter the username" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Password*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="user_pwd" value="<?php if (isset($_POST['user_pwd'])) echo $_POST['user_pwd'];?>" data-error="Please enter the password to make change" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Role</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="user_role" value="<?php if (isset($_POST['user_role'])) echo $_POST['user_role'];?>" data-error="Please select the role for user" required>
                                    <option disabled selected value> -- </option>
                                    <?php
                                        $selected = get_user_role($dbc, $user_id);
                                        require( 'includes/connect_db_c9.php' ) ; 
	                                    $query = "SELECT DISTINCT USER_ROLE FROM IDCP_USER";
	                                    $results = mysqli_query($dbc, $query);
                                        if($results){
                                	        while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) ){
                                        	    $role = $row['USER_ROLE'];
                                                if($selected == $role){
                                                    echo "<option selected='selected' value='$role'>$role</option>" ;
                                                }else{
                                                    echo "<option value='$role'>$role</option>" ;
                                                }
                                	        }
                            	         }
                                	    else{
                                	        echo "Error";
                                	    }
                                        # Free up the results in memory
                                    	mysqli_free_result( $results );
                                    	mysqli_close( $dbc ) ;
                                    ?>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button class="btn btn-default" type="button" onclick ="location.href='user_settings.php';">Back</button>
                                <button type="submit" class="btn btn-default">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>