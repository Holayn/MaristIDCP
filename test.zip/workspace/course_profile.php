<?php 
    $title = "IDCP - Course Profile";
    require('includes/header.php');
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/course_helpers.php' ) ;
    $crs_id = $_SESSION['CRS_ID'];

?>


<style>
    .inline {
  display: inline;
}

.link-button {
  background: none;
  border: none;

}
.link-button:focus {
  outline: none;


}

.link-button:hover {
  outline: none;
  

}
.link-button:active {
  color:white;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="page-header">
                    <h1>
                        <?php
                            echo get_crs_name($dbc, $crs_id);
                        ?>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">Course Information</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <p><label>Course ID: </label><br>
                                    <?php
                                     echo $crs_id;
                                    ?>
                                    </p>
                                    <p><label>Course Name:</label><br>
                                    <?php
                                      echo get_crs_name($dbc, $crs_id);
                                    ?>
                                    </p>
                                    <p><label>Course Level:</label><br>
                                    <?php
                                      echo get_crs_level($dbc, $crs_id);
                                    ?>
                                    </p>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='edit_course.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-default btn-sm" onclick ="location.href='course_search.php';">Back</button>
                    </div>
                </div>
            <!-- /#container close -->
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->
    <script> $('.datepicker').datepicker(); </script>
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
