<?php 
    $title = "IDCP - Certificate Details";
    require('includes/header.php');
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/certificate_helpers.php' ) ;
        # Check to make sure it is the first time user is visiting the page
    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        $cert_id= $_SESSION['CERT_ID'];
        $earn_year = "";
    // 	$earn_mon = "";
    // 	$earn_day = "";
        $_SESSION['searchString'] = "";
    }
    # Check to make sure the form method is post
//     if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
//         $cert_id= $_SESSION['CERT_ID'];
//     // 	$stu_id = $_POST['stu_id'];
//     // 	$stu_name = $_POST['stu_name'];
//     	$earn_year = $_POST['earn_year'];
//     // 	$earn_mon = $_POST['earn_mon'];
//     // 	$earn_day = $_POST['earn_day'];
// // 		$stu_id = trim($stu_id);
// // 		$stu_name = trim($stu_name);
// // 		$page = 'certificate_add_success.php';
// // 		header("Location: $page");
//     }
?>

<script>
    function showField(str) {
      if (str=="") {
        document.getElementById("field_display").innerHTML="";
        return;
      } 
      if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
      } else { // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function() {
        if (this.readyState==4 && this.status==200) {
          document.getElementById("field_display").innerHTML=this.responseText;
        }
      }
      //str =
      str1 = $( "#cert_id" ).text()+ "." + str;
      xmlhttp.open("GET","backendcertrpt.php?q="+str1,true);
      xmlhttp.send();
    }
</script>

<style>
    .inline {
  display: inline;
}

.link-button {
  background: none;
  border: none;

}
.link-button:focus {
  outline: none;


}

.link-button:hover {
  outline: none;
  

}
.link-button:active {
  color:white;
}
</style>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1000px;">-->
                <div class="page-header">
                    <h1>
                        <?php
                            echo get_cert_name($dbc, $cert_id);
                        ?>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    Certificate Info
                                </h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label>ID</label><br>
                                    <p id="cert_id">
                                        <?php
    				                        echo $cert_id;                                
    				                    ?>
				                    </p>
                                    <p><label>Program</label><br>
                                        <?php
                                         echo get_prg_name($dbc, $cert_id);
                                        ?>
                                    </p>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='certificate_edit.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                </div>
                    <form action="certificate_detail.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Filter by:<small> Fill out as many fields as needed</small></h3>
                            </div>
                        </div>
                        <!--<div class="form-group">-->
                        <!--    <label class="col-xs-3 control-label">Student ID*</label>-->
                        <!--    <div class="col-xs-2">-->
                        <!--        <input type="text" class="form-control" name="stu_id" value="<?php if (isset($_POST['stu_id'])) echo $_POST['stu_id'];?>" data-error="Please enter the student id" required>-->
                        <!--    </div>-->
                        <!--    <div class="help-block with-errors"></div>-->
                        <!--</div>-->
                        
                        <!--<div class="form-group">-->
                        <!--    <label class="col-xs-3 control-label">Student Name*</label>-->
                        <!--    <div class="col-xs-2">-->
                        <!--        <input type="text" class="form-control" name="stu_name" value="<?php if (isset($_POST['stu_name'])) echo $_POST['stu_name'];?>" data-error="Please enter the student name" required>-->
                        <!--    </div>-->
                        <!--    <div class="help-block with-errors"></div>-->
                        <!--</div>-->
                        <div class="form-group">
                            <!--<div class="row">-->
                                <label class="col-xs-3 control-label" for="earn_yr">Earn Year*</label>
                                <div class="col-xs-2">
                                    <select class="form-control" id="earn_yr" name="earn_yr1" value="<?php if (isset($_POST['earn_yr'])) echo $_POST['earn_yr'];?>" onchange="showField(this.value)" data-error="Please select the earn date" required>
                                        <option disabled selected value>--</option>
                                        <?php
                                        $selected = $earn_yr;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                                  </select>
                                </div>
                                <div class="help-block with-errors"></div>
                        </div>
                <div id="field_display" class="span3" style="height: 200px; overflow: auto;"> 
                    <?php
                            show_brief_certificate_students($dbc, $cert_id);
                    ?>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <button class="btn btn-default btn-sm" type="button" onclick="location.href='certificate_search.php';">Back to Search</button>
                    </div>
                </div>
            <!-- /#container close -->
            </div>
        <!-- /#page-content-wrapper -->
        </div>
    </div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>
