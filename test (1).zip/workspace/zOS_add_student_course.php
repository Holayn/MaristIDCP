<!--Allows user to add course for student -->
<!DOCTYPE html>
<html lang="en">
<?php
        session_start();
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/student_helpers.php' ) ;
        # Check to make sure it is the first time user is visiting the page
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            $crs_name = "";
            $crs_enroll_yr_start = "";
            $crs_enroll_mon_start = "";
            $crs_enroll_day_start = "";
            $credit = "";
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
            $crs_name = $_POST['crs_name'];
            //This is actually the course name, not the ID
            $crs_pieces = explode(" ", $crs_name);
            $crs_id = $crs_pieces[0];
            $crs_enroll_yr_start = $_POST['crs_enroll_yr_start'];
            $crs_enroll_mon_start = $_POST['crs_enroll_mon_start'];
            $crs_enroll_day_start = $_POST['crs_enroll_day_start'];
            if($crs_enroll_mon_start == "January"){
        	    $crs_enroll_mon_start = 1;
        	}
        	if($crs_enroll_mon_start == "February"){
        	    $crs_enroll_mon_start = 2;
        	}
        	if($crs_enroll_mon_start == "March"){
        	    $crs_enroll_mon_start = 3;
        	}
        	if($crs_enroll_mon_start == "April"){
        	    $crs_enroll_mon_start = 4;
        	}
        	if($crs_enroll_mon_start == "May"){
        	    $crs_enroll_mon_start = 5;
        	}
        	if($crs_enroll_mon_start == "June"){
        	    $crs_enroll_mon_start = 6;
        	}
        	if($crs_enroll_mon_start == "July"){
        	    $crs_enroll_mon_start = 7;
        	}
        	if($crs_enroll_mon_start == "August"){
        	    $crs_enroll_mon_start = 8;
        	}
        	if($crs_enroll_mon_start == "September"){
        	    $crs_enroll_mon_start = 9;
        	}
        	if($crs_enroll_mon_start == "October"){
        	    $crs_enroll_mon_start = 10;
        	}
        	if($crs_enroll_mon_start == "November"){
        	    $crs_enroll_mon_start = 11;
        	}
        	if($crs_enroll_mon_start == "December"){
        	    $crs_enroll_mon_start = 12;
        	}
            $credit = $_POST['credit'];
            	if($credit == "Yes"){
        	    $credit = 1;
        	}
        	else{
        	    $credit = 0;
        	}
            $stu_id = $_SESSION['stu_id'];
    		$result = insert_record_crs_enrolled($dbc, $credit, $crs_enroll_yr_start, $crs_enroll_mon_start, $crs_enroll_day_start, $crs_id, $stu_id);
    		echo "Success! Thanks" ; 
    		$_SESSION['addedCourse'] = true;
    		$page = 'zOS_add_student_course_home.php';
            header("Location: $page");
        }
        # Close the connection
        mysqli_close( $dbc ) ;
        ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IDCP</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/banner.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
</head>

<body>
    <img src='placeholder.png' style="visibility: hidden;" id="banner">
	<!--Navigation Bars-->
    <div id="wrapper">
        <!--<img src="IDCPorig.png" id="banner">-->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <img src="IDCPlogo.PNG" id="banner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="user_settings.php"><i class="fa fa-fw fa-user"></i> User Settings</a>
                        </li>
                        <li>
                            <a href="idcp_settings.php"><i class="fa fa-fw fa-gear"></i> IDCP Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        <!--</div>-->
        <!--<div id="wrapper">-->
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
             <!--top: 145px;-->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" style="margin-top:7%;">
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#zOS"> z/OS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="zOS" class="collapse">
                           <li>
                                <a href="zOS_student.php">Students</a>
                            </li>
                            <li>
                                <a href="zOS_course.php">Courses</a>
                            </li>
                            <li>
                                <a href="generate_report.php">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#dataCenter"> Data Center <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="dataCenter" class="collapse">
                            <li>
                                <a href="#">Students</a>
                            </li>
                            <li>
                                <a href="#">Courses</a>
                            </li>
                            <li>
                                <a href="#">Report</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <div class="page-header">
                        <!--Make this dynamic-->
                        <?php
    				        $stu_id = $_SESSION['stu_id'];
    				        $name = get_stu_name($dbc, $stu_id);
    				        echo '<h1>z/OS Student - Add a Course for ' . "$name" . '</h1>';
    				    ?>
				    </div>
                    <form action="zOS_add_student_course.php" method="POST" class="form-horizontal" role="form" data-toggle="validator">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Enrollment Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Course Name*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="crs_name" value="<?php if (isset($_POST['crs_name'])) echo $_POST['crs_name'];?>" data-error="Please select the course name" required>
                                <option disabled selected value>-- select an option --</option>
                                <?php
                                    require( 'includes/connect_db_c9.php' ) ;
                                    $query = 'SELECT CRS_ID, CRS_NAME FROM COURSE';
	                                $results = mysqli_query($dbc, $query);
	                                if($results){
	                                    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
                                		{
                                			echo '<option>' . $row['CRS_ID'] . " " . $row['CRS_NAME'] . '</option>' ;
                                		}
	                                }
	                                else
                                	{
                                		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
                                	}
                                	# Free up the results in memory
                                	mysqli_free_result( $results );
                                	mysqli_close( $dbc ) ;
                                ?>
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                            <button class="btn btn-default" onclick="location.href='zOS_add_course.php';">Add a Course</button>
                        </div>
                        <div class="form-group">
                            <!--<div class="row">-->
                                <label class="col-xs-3 control-label" for="sel1">Enroll Year*</label>
                                <div class="col-xs-2">
                                    <select class="form-control" id="sel1" name="crs_enroll_yr_start" value="<?php if (isset($_POST['crs_enroll_yr_start'])) echo $_POST['crs_entroll_yr_start'];?>" data-error="Please select the student's enroll year" required>
                                        <option disabled selected value>--</option>
                                        <?php
                                        $selected = $crs_enroll_yr_start;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                                  </select>
                                </div>
                                <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Enroll Month*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_mon_start" value="<?php if (isset($_POST['crs_enroll_mon_start'])) echo $_POST['crs_enroll_mon_start'];?>" data-error="Please select the student's enroll month" required>
                                    <option disabled selected value>--</option>
                                    <option>January</option>
                                    <option>February</option>
                                    <option>March</option>
                                    <option>April</option>
                                    <option>May</option>
                                    <option>June</option>
                                    <option>July</option>
                                    <option>August</option>
                                    <option>September</option>
                                    <option>October</option>
                                    <option>November</option>
                                    <option>December</option>
                                  </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Enroll Day*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_day_start" value="<?php if (isset($_POST['crs_enroll_day_start'])) echo $_POST['crs_enroll_day_start'];?>" data-error="Please select the student's enroll day" required>
                                    <option disabled selected value>--</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                    <option>16</option>
                                    <option>17</option>
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Taking for Credit?*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="credit" value="<?php if (isset($_POST['credit'])) echo $_POST['credit'];?>" data-error="Please select if the student is taking the course for credit" required>
                                    <option disabled selected value>--</option>
                                    <option>Yes</option>
                                    <option>No</option>
                                  </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>

</body>

</html>
