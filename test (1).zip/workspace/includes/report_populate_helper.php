<?php

$debug = true;

$p = strtoupper($_GET['p']);
$q = $_GET['q'];

require('connect_db_c9.php');

mysqli_select_db($dbc,"ajax_demo");

if(isset($p)&&!isset($q)){
$r = $p;
$query ="SELECT * FROM ".$p."";
$results = mysqli_query($dbc,$query);

echo "<label>about:</label>";
echo $sql;
echo "<select class=\"form-control\" name=\"field\" value=\"<?php if (isset(\$_POST[\'field\'])) echo \$_POST[\'field\'];?>\" onchange=\"showOption(this.value)\">";
    if($results){
		while ($fieldinfo=mysqli_fetch_field($results)){
		{
			echo '<option value="'.$fieldinfo->name.'">'.$fieldinfo->name.'</option>';
			}
		}
    }
    else
	{
		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
	}
echo "</select>";
}
else if(isset($q)){
	$q = explode(".", $q);
	$query ="SELECT DISTINCT ".$q[0]." FROM ".strtoupper($q[1])."";
	$results = mysqli_query($dbc,$query);
	
	echo "<label>specifically:</label>";
	echo $query;
	echo "<select class=\"form-control\" name=\"spec\" value=\"<?php if (isset(\$_POST[\'spec\'])) echo \$_POST[\'spec\'];?>\">";
	    if($results){
	        while ($row = mysqli_fetch_array($results,MYSQLI_NUM))
			{
				$row_id = 0;
				while ($row_id < count($row)){
					echo '<option>'.$row[$row_id].'</option>';
					$row_id++;
				}
			}
	    }
	    else
		{
			echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
		}
	echo "</select>";
	mysqli_close($dbc);
}

?>
 