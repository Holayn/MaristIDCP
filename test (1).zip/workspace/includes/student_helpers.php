<?php
$debug = true;
function load($page = 'zOS_add_student.php', $stu_id = -1){
	session_start();
	header("Location: $page");
	$_SESSION['stu_id'] = $stu_id;
	$_SESSION['addedCourse'] = false;
	exit();
}

function loadSearch($page = 'zOS_add_student.php', $stu_id = -1){
	session_start();
	header("Location: $page");
	$_SESSION['stu_id'] = $stu_id;
	exit();
}

# Insert functions
function insert_record($dbc, $stu_id, $stu_tag, $stu_lname, $stu_fname, $stu_initial, $stu_yr_start, $stu_mon_start, $stu_day_start, $stu_edu_lvl, $stu_job_title, $stu_street, $stu_city, $stu_state, $stu_country, $stu_zip, $stu_phone, $stu_email_1, $stu_email_2, $stu_yr_dob, $stu_mon_dob, $stu_day_dob, $stu_ethnicity, $stu_gender, $stu_citizen, $stu_transcript, $stu_qualify_exam, $stu_comment, $emp_id) {
  $query = 'INSERT INTO STUDENT(STU_ID, STU_TAG, STU_LNAME, STU_FNAME, STU_INITIAL, STU_YR_START, STU_MON_START, STU_DAY_START, STU_EDU_LVL, STU_JOB_TITLE, STU_STREET, STU_CITY, STU_STATE, STU_COUNTRY, STU_ZIP, STU_PHONE, STU_EMAIL_1, STU_EMAIL_2, STU_YR_DOB, STU_MON_DOB, STU_DAY_DOB, STU_ETHNICITY, STU_GENDER, STU_CITIZEN, STU_TRANSCRIPT, STU_QUALIFY_EXAM, STU_COMMENT, EMP_ID) VALUES ('.$stu_id.' , '.$stu_tag.' , "'.$stu_lname.'" , "'.$stu_fname.'" , "'.$stu_initial.'" , '.$stu_yr_start.' , '.$stu_mon_start.' , '.$stu_day_start.' , "'.$stu_edu_lvl.'" , "'.$stu_job_title.'" , "'.$stu_street.'" , "'.$stu_city.'" , "'.$stu_state.'" , "'.$stu_country.'" , "'.$stu_zip.'" , "'.$stu_phone.'" , "'.$stu_email_1.'" , "'.$stu_email_2.'" , '.$stu_yr_dob.' , '.$stu_mon_dob.' , '.$stu_day_dob.' , "'.$stu_ethnicity.'" , "'.$stu_gender.'" , '.$stu_citizen.' , '.$stu_transcript.' , '.$stu_qualify_exam.' , "'.$stu_comment.'" , '.$emp_id.')' ;
  //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}
function update_record($dbc, $stu_id, $stu_tag, $stu_lname, $stu_fname, $stu_initial, $stu_yr_start, $stu_mon_start, $stu_day_start, $stu_yr_end, $stu_mon_end, $stu_day_end, $stu_edu_lvl, $stu_job_title, $stu_street, $stu_city, $stu_state, $stu_country, $stu_zip, $stu_phone, $stu_email_1, $stu_email_2, $stu_yr_dob, $stu_mon_dob, $stu_day_dob, $stu_ethnicity, $stu_gender, $stu_citizen, $stu_transcript, $stu_qualify_exam, $stu_comment, $emp_id) {
  $query = 'UPDATE STUDENT SET STU_TAG = '.$stu_tag.' , STU_LNAME = "'.$stu_lname.'" , STU_FNAME = "'.$stu_fname.'" , STU_INITIAL = "'.$stu_initial.'" , STU_YR_START = '.$stu_yr_start.' , STU_MON_START = '.$stu_mon_start.' , STU_DAY_START = '.$stu_day_start.' , STU_YR_END = '.$stu_yr_end.' , STU_MON_END = '.$stu_mon_end.' , STU_DAY_END = '.$stu_day_end.' , STU_EDU_LVL = "'.$stu_edu_lvl.'" , STU_JOB_TITLE = "'.$stu_job_title.'" , STU_STREET = "'.$stu_street.'" , STU_CITY = "'.$stu_city.'" , STU_STATE = "'.$stu_state.'" , STU_COUNTRY = "'.$stu_country.'" , STU_ZIP = "'.$stu_zip.'" , STU_PHONE = "'.$stu_phone.'" , STU_EMAIL_1 = "'.$stu_email_1.'" , STU_EMAIL_2 = "'.$stu_email_2.'" , STU_YR_DOB = '.$stu_yr_dob.' , STU_MON_DOB = '.$stu_mon_dob.' , STU_DAY_DOB = '.$stu_day_dob.' , STU_ETHNICITY = "'.$stu_ethnicity.'" , STU_GENDER = "'.$stu_gender.'" , STU_CITIZEN = '.$stu_citizen.' , STU_TRANSCRIPT = '.$stu_transcript.' , STU_QUALIFY_EXAM = '.$stu_qualify_exam.' , STU_COMMENT = "'.$stu_comment.'" , EMP_ID = '.$emp_id.' WHERE STU_ID = '.$stu_id;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}
function insert_record_crs_enrolled($dbc, $credit, $crs_enroll_yr_start, $monthname, $crs_enroll_day_start, $crs_id, $stu_id){
	$query = 'INSERT INTO CRS_ENROLLED(CREDIT, CRS_ENROLL_STATUS, CRS_ENROLL_YR_START, monthname, CRS_ENROLL_DAY_START, CRS_ID, STU_ID) VALUES ('.$credit.' , "Active" , '.$crs_enroll_yr_start.' , '.$monthname.' , '.$crs_enroll_day_start.' , "'.$crs_id.'" , '.$stu_id.')';
	//show_query($query);
	$results = mysqli_query($dbc,$query) ;
	//check_results($results) ;
	return $results ;
}
function update_record_crs_enrolled($dbc, $credit, $grade, $crs_enroll_status, $crs_enroll_yr_start, $crs_enroll_mon_start, $crs_enroll_day_start, $crs_enroll_yr_end, $crs_enroll_mon_end, $crs_enroll_day_end, $crs_id, $stu_id){
	$query = 'UPDATE CRS_ENROLLED SET CREDIT = '.$credit.', CRS_ENROLL_STATUS = "'.$crs_enroll_status.'", GRADE = "'.$grade.'", CRS_ENROLL_YR_START = '.$crs_enroll_yr_start.', CRS_ENROLL_DAY_START = '.$crs_enroll_day_start.', CRS_ENROLL_MON_START = '.$crs_enroll_mon_start.', CRS_ENROLL_DAY_END = '.$crs_enroll_day_end.', CRS_ENROLL_MON_END = '.$crs_enroll_mon_end.', CRS_ENROLL_YR_END = '.$crs_enroll_yr_end.' WHERE STU_ID = '.$stu_id.' AND CRS_ID = '.$crs_id;
  show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}
# Converts month number to its name
function month_num_to_name($monthnum){
	$months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	return $months[$monthnum-1];
                                        
}
# Converts month name to its number
function month_name_to_num($monthname){
	if($monthname == "January"){
	    $monthname = 1;
	}
	if($monthname == "February"){
	    $monthname = 2;
	}
	if($monthname == "March"){
	    $monthname = 3;
	}
	if($monthname == "April"){
	    $monthname = 4;
	}
	if($monthname == "May"){
	    $monthname = 5;
	}
	if($monthname == "June"){
	    $monthname = 6;
	}
	if($monthname == "July"){
	    $monthname = 7;
	}
	if($monthname == "August"){
	    $monthname = 8;
	}
	if($monthname == "September"){
	    $monthname = 9;
	}
	if($monthname == "October"){
	    $monthname = 10;
	}
	if($monthname == "November"){
	    $monthname = 11;
	}
	if($monthname == "December"){
	    $monthname = 12;
	}
	return $monthname;
}
#Lists out the active courses for a student
function show_active_courses($dbc, $stu_id){
  $query = 'SELECT * FROM CRS_ENROLLED WHERE CRS_ENROLL_STATUS = "Active" AND STU_ID = ' . $stu_id;
  $results = mysqli_query($dbc, $query);
  if($results){
  		echo '<TABLE class="table table-condensed table-striped table-hover">';
  		echo '<THEAD>';
  		echo '<TR>';
  		echo '<TH>ID</TH>';
  		echo '<TH>Enroll Year</TH>';
  		echo '<TH>Enroll Month</TH>';
  		echo '<TH>Enroll Day</TH>';
  		echo '<TH>Completion Year</TH>';
  		echo '<TH>Completion Month</TH>';
  		echo '<TH>Completion Day</TH>';
  		echo '<TH>Grade</TH>';
  		echo '<TH>Credit</TH>';
  		echo '<TH>Status</TH>';
  		echo '</TR>';
  		echo '</THEAD>';
  		echo '<TBODY>';
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
  			// echo '<form action="zOS_edit_student_course.php" method="POST">';
  			echo "<TR class='clickable-row'>";
  			echo '<TD>' . $row['CRS_ID'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_START'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_START']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_START'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_END'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_END']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_END'] . '</TD>' ;
  			echo '<TD>' . $row['GRADE'] . '</TD>' ;
  			if($row['CREDIT'] == 1){
  				echo '<TD>' . Yes . '</TD>' ;
  			}
  			else{
  				echo '<TD>' . No . '</TD>' ;
  			}
  			echo '<TD>' . $row['CRS_ENROLL_STATUS'] . '</TD>' ;
  			echo '</TR>';
  			// echo '<input type="hidden" name="CRS_ID" value="'.$row['CRS_ID'].'">';
  			// echo '</form>';
  		}
  		echo '</TBODY>';
  		echo '</TABLE>';
      }
	# Free up the results in memory
	mysqli_free_result( $results );
	# DONT CLOSE CONNECTION YET!
	// mysqli_close( $dbc ) ;
}
function show_completed_courses($dbc, $stu_id){
	$query = 'SELECT * FROM CRS_ENROLLED WHERE CRS_ENROLL_STATUS = "Completed" AND STU_ID = ' . $stu_id;
  $results = mysqli_query($dbc, $query);
  if($results){
  		echo '<TABLE class="table table-condensed table-striped table-hover">';
  		echo '<THEAD>';
  		echo '<TR>';
  		echo '<TH>ID</TH>';
  		echo '<TH>Enroll Year</TH>';
  		echo '<TH>Enroll Month</TH>';
  		echo '<TH>Enroll Day</TH>';
  		echo '<TH>Completion Year</TH>';
  		echo '<TH>Completion Month</TH>';
  		echo '<TH>Completion Day</TH>';
  		echo '<TH>Grade</TH>';
  		echo '<TH>Credit</TH>';
  		echo '<TH>Status</TH>';
  		echo '</TR>';
  		echo '</THEAD>';
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
  			echo '<TR>' ;
  			echo '<TD>' . $row['CRS_ID'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_START'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_START']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_START'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_END'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_END']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_END'] . '</TD>' ;
  			echo '<TD>' . $row['GRADE'] . '</TD>' ;
  			if($row['CREDIT'] == 1){
  				echo '<TD>' . Yes . '</TD>' ;
  			}
  			else{
  				echo '<TD>' . No . '</TD>' ;
  			}
  			echo '<TD>' . $row['CRS_ENROLL_STATUS'] . '</TD>' ;
  			echo '</TR>';
  		}
  		echo '</TABLE>';
      }
	# Free up the results in memory
	mysqli_free_result( $results );
	// mysqli_close( $dbc ) ;
}
#Shows inactive courses of the student. These courses are probably dropped or failed.
function show_inactive_courses($dbc, $stu_id){
	$query = 'SELECT * FROM CRS_ENROLLED WHERE CRS_ENROLL_STATUS <> "Completed" AND CRS_ENROLL_STATUS <> "Active" AND STU_ID = ' . $stu_id;
  $results = mysqli_query($dbc, $query);
  if($results){
  		echo '<TABLE class="table table-condensed table-striped table-hover">';
  		echo '<THEAD>';
  		echo '<TR>';
  		echo '<TH>ID</TH>';
  		echo '<TH>Enroll Year</TH>';
  		echo '<TH>Enroll Month</TH>';
  		echo '<TH>Enroll Day</TH>';
  		echo '<TH>Completion Year</TH>';
  		echo '<TH>Completion Month</TH>';
  		echo '<TH>Completion Day</TH>';
  		echo '<TH>Grade</TH>';
  		echo '<TH>Credit</TH>';
  		echo '<TH>Status</TH>';
  		echo '</TR>';
  		echo '</THEAD>';
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
  			echo "<TR>";
  			echo '<TD>' . $row['CRS_ID'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_START'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_START']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_START'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_END'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_END']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_END'] . '</TD>' ;
  			echo '<TD>' . $row['GRADE'] . '</TD>' ;
  			if($row['CREDIT'] == 1){
  				echo '<TD>' . Yes . '</TD>' ;
  			}
  			else{
  				echo '<TD>' . No . '</TD>' ;
  			}
  			echo '<TD>' . $row['CRS_ENROLL_STATUS'] . '</TD>' ;
  			echo '</TR>';
  		}
  		echo '</TABLE>';
      }
	# Free up the results in memory
	mysqli_free_result( $results );
	mysqli_close( $dbc ) ;
}
# Shows courses student is enrolled in in a table. Used for while adding courses for a new student
function show_student_courses($dbc, $stu_id){
  $query = 'SELECT * FROM CRS_ENROLLED WHERE STU_ID = ' . $stu_id;
  $results = mysqli_query($dbc, $query);
  if($results){
  		echo '<TABLE class="table table-condensed">';
  		echo '<TR>';
  		echo '<TH>ID</TH>';
  		echo '<TH>Enroll Year</TH>';
  		echo '<TH>Enroll Month</TH>';
  		echo '<TH>Enroll Day</TH>';
  		echo '<TH>Completion Year</TH>';
  		echo '<TH>Completion Month</TH>';
  		echo '<TH>Completion Day</TH>';
  		echo '<TH>Grade</TH>';
  		echo '<TH>Credit</TH>';
  		echo '<TH>Status</TH>';
  		echo '</TR>';
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
  			echo '<TR>' ;
  			echo '<TD>' . $row['CRS_ID'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_START'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_START']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_START'] . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_YR_END'] . '</TD>' ;
  			echo '<TD>' . month_num_to_name($row['CRS_ENROLL_MON_END']) . '</TD>' ;
  			echo '<TD>' . $row['CRS_ENROLL_DAY_END'] . '</TD>' ;
  			echo '<TD>' . $row['GRADE'] . '</TD>' ;
  			if($row['CREDIT'] == 1){
  				echo '<TD>' . Yes . '</TD>' ;
  			}
  			else{
  				echo '<TD>' . No . '</TD>' ;
  			}
  			echo '<TD>' . $row['STATUS'] . '</TD>' ;
  			echo '</TR>';
  		}
  		echo '</TABLE>';
      }
	# Free up the results in memory
	mysqli_free_result( $results );
	mysqli_close( $dbc ) ;
}

# Gets the id of the student
function get_student_id($dbc, $stu_name){
	$query = "SELECT STU_ID FROM STUDENT WHERE STU_FNAME = '".$stu_name."'";
	$results = mysqli_query($dbc,$query) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$stu_id = $row [ 'STU_ID' ] ;
	return intval($stu_id) ;
}
# Gets the id of the course
function get_crs_id($dbc, $crs_name){
	$query = "SELECT CRS_ID FROM COURSE WHERE CRS_NAME = '".$crs_name."'";
	$results = mysqli_query($dbc,$query) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$crs_id = $row [ 'CRS_ID' ] ;
	return $crs_id;
}
function get_emp_name($dbc, $emp_id){
	$query = "SELECT EMP_NAME FROM EMPLOYER WHERE EMP_ID = $emp_id";
	$results = mysqli_query($dbc,$query) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$emp_id= $row [ 'EMP_NAME' ] ;
	return $emp_id;
}
# Gets the id of the employer
function get_employer_id($dbc, $emp_name){
	$query = "SELECT EMP_ID FROM EMPLOYER WHERE EMP_NAME = '".$emp_name."'";
	$results = mysqli_query($dbc,$query) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$emp_id = $row [ 'EMP_ID' ] ;
	return intval($emp_id) ;
}
# Gets the full name of the student from the student ID
function get_stu_name($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT STU_FNAME, STU_LNAME FROM STUDENT WHERE STU_ID = $stu_id";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if($results){
    $row = mysqli_fetch_array($results, MYSQLI_ASSOC);
    $fname = $row [ 'STU_FNAME' ] ;
    $lname = $row [ 'STU_LNAME' ] ;
    $name = $fname . " " . $lname;
    return $name;
    }
    else{
    		echo $stu_id;
    }
}
# Gets the course name from course id
function get_crs_name($dbc, $crs_id){
	require( 'includes/connect_db_c9.php' ) ;
	$query = "SELECT CRS_NAME FROM COURSE WHERE CRS_ID = $crs_id";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if($results){
    $row = mysqli_fetch_array($results, MYSQLI_ASSOC);
    $name = $row [ 'CRS_NAME' ] ;
    return $name;
    }
    else{
    		echo $crs_id;
    }
}
function get_stu_gender($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT STU_GENDER FROM STUDENT WHERE STU_ID = $stu_id";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$stu_gender = $row [ 'STU_GENDER' ] ;
	return $stu_gender ;
}

function get_stu_yr_start($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT STU_YR_START FROM STUDENT WHERE STU_ID = $stu_id";
  $results = mysqli_query( $dbc, $query ) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$stu_yr_start = $row [ 'STU_YR_START' ] ;
	return $stu_yr_start ;
}
function get_stu_mon_start($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT STU_MON_START FROM STUDENT WHERE STU_ID = $stu_id";
  $results = mysqli_query( $dbc, $query ) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$stu_yr_start = $row [ 'STU_MON_START' ] ;
	return $stu_yr_start ;
}
function get_stu_day_start($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT STU_DAY_START FROM STUDENT WHERE STU_ID = $stu_id";
  $results = mysqli_query( $dbc, $query ) ;
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$stu_yr_start = $row [ 'STU_DAY_START' ] ;
	return $stu_yr_start ;
}
#Shows 3 recent courses the student has taken/is in
function show_recent_student_courses($dbc, $stu_id){
	require( 'includes/connect_db_c9.php' ) ; //Not sure why we need this here...
	$query = "SELECT COURSE.CRS_ID, COURSE.CRS_NAME, CRS_ENROLLED.CRS_ENROLL_STATUS FROM CRS_ENROLLED, COURSE WHERE CRS_ENROLLED.CRS_ID = COURSE.CRS_ID AND CRS_ENROLLED.STU_ID = $stu_id";
  $results = mysqli_query( $dbc, $query ) ;
  $counter = 0;
	while($row = mysqli_fetch_array($results, MYSQLI_ASSOC)){
		if($counter < 3){
			echo '<p><label>'.$row['CRS_ID'].'</label><br>';
			echo $row['CRS_NAME'] . " (" . $row['CRS_ENROLL_STATUS'] . ")";
			echo '</p>';
			$counter++;
		}
	}
	$stu_yr_start = $row [ 'STU_DAY_START' ] ;
}

# Shows the query as a debugging aid
function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

# Checks the query results as a debugging aid
function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}

#Created function that validates a number
function valid_number($num) {
	if (empty($num) || !is_numeric($num))
			return false;
	else {
		$num = intval($num);
		if($num <= 0)
			return false;
	}
	return true;
}

#Created function that validates name input
function valid_name($name) {
	if (empty($name))
		return false;
	else 
		return true;
}




?>