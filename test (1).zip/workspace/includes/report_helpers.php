<?php

$debug = true;

function show_course($dbc, $statement){
	require('connect_db_c9.php');

	$query = ''.$statement.'';
	//$query = 'SELECT * FROM course';
	$results = mysqli_query($dbc,$query);
	$field_count = 0;
	if ($results){
		echo '<TABLE border=2>';
		echo '<TR>';
		while ($fieldinfo=mysqli_fetch_field($results)){
			echo '<TH>'.$fieldinfo->name.'</TH>';
		}
		echo '</TR>';
		while ($row = mysqli_fetch_array($results,MYSQLI_NUM)){
			echo '<TR>';
			$row_id = 0;
			while ($row_id < count($row)){
			echo '<TD>'.$row[$row_id].'</TD>';
			$row_id++;
			}
			echo '</TR>';
		}
		echo '</TABLE>';
		mysqli_free_result($results) ;
	}
	else{
		echo '<p>'.mysqli_error($dbc).'</p>';
	}
	mysqli_close($dbc);
}

function generate_report($dbc,$statement){
	require('connect_db_c9.php');
	if($statement='')
		$statement = 'SELECT * FROM INSTRUCTOR';
	$query = ''.$statement.'';
	$result = mysqli_query($dbc,$query);
}

function show_stu_crs($dbc,$id){
	require('connect_db_c9.php');
	$query = 'SELECT CRS_NAME, CRS_ENROLL_STATUS FROM COURSE, CRS_ENROLLED WHERE COURSE.CRS_ID=CRS_ENROLLED.CRS_ID AND STU_ID='.$id.'';
	$results = mysqli_query($dbc,$query);
	if($results){
		while ($row = mysqli_fetch_array($results,MYSQLI_NUM)){
				echo '<LABEL>'.$row[0].'</LABEL>';
				echo '<p class="form-control-static">'.$row[1].'<p class="form-control-static">';
			}
			mysqli_free_result($results) ;
	}
	else{
		echo '<p>'.mysqli_error($dbc).'</p>';
	}
	mysqli_close($dbc);
}

function show_stu_cert($dbc,$id){
	require('connect_db_c9.php');
	$query = 'SELECT CERT_NAME, CONCAT(EARN_MON,\'/\',EARN_DAY,\'/\',EARN_YR)AS EARN_DATE FROM CERTIFICATE AS C, CERT_EARNED AS CE WHERE C.CERT_ID=CE.CERT_ID AND STU_ID='.$id.'';
	$results = mysqli_query($dbc,$query);
	if($results){
		while ($row = mysqli_fetch_array($results,MYSQLI_NUM)){
				echo '<LABEL>'.$row[0].'</LABEL>';
				echo '<p class="form-control-static">'.$row[1].'<p class="form-control-static">';
			}
			mysqli_free_result($results) ;
	}
	else{
		echo '<p>'.mysqli_error($dbc).'</p>';
	}
	mysqli_close($dbc);
}

function show_basic_report($dbc,$statement){
	require('connect_db_c9.php');
	$query = ''.$statement.'';
	echo $query;
	//$query = 'SELECT * FROM course';
	$results = mysqli_query($dbc,$query);
	$field_count = 0;
	if ($results){
		echo '<THEAD>';
		echo '<TR>';
		while ($fieldinfo=mysqli_fetch_field($results)){
			echo '<TH>'.$fieldinfo->name.'</TH>';
		}
		echo '</TR>';
		echo '</THEAD>';
		echo '<TBODY>';
		while ($row = mysqli_fetch_array($results,MYSQLI_NUM)){
			echo '<TR>';
			$row_id = 0;
			while ($row_id < count($row)){
			echo '<TD>'.$row[$row_id].'</TD>';
			$row_id++;
			}
			echo '</TR>';
		}
		echo '</TBODY>';
		mysqli_free_result($results) ;
	}
	else{
		echo '<p>'.mysqli_error($dbc).'</p>';
	}
	mysqli_close($dbc);
}

function populate_specific($dbc, $choice, $entity){
	require( 'includes/connect_db_c9.php' ) ;
	$query = 'SELECT '.$choice.' FROM '.$entity.'';
    $results = mysqli_query($dbc, $query);
    if($results){
        while ($row = mysqli_fetch_array($results,MYSQLI_NUM))
		{
			$row_id = 0;
			while ($row_id < count($row)){
				echo '<option>'.$row[$row_id].'</option>';
				$row_id++;
			}
		}
    }
    else
	{
		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
	}
	mysqli_free_result( $results );
	mysqli_close( $dbc ) ;
}
?>
