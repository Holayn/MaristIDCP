<?php
  require( 'includes/connect_db_c9.php' ) ; 

$debug = true;
function insert_course($dbc, $crs_id, $crs_name, $crs_level) {
  $query = 'INSERT INTO COURSE(CRS_ID, CRS_NAME, CRS_LEVEL) VALUES ("'.$crs_id.'" , "'.$crs_name.'" , "'.$crs_level.'")' ;
 //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function update_course($dbc, $crs_id, $crs_name, $crs_level) {
  $query = 'UPDATE COURSE SET CRS_NAME = "'.$crs_name.'", CRS_LEVEL = "'.$crs_level.'" WHERE CRS_ID = "'.$crs_id.'"';
  //show_query($query);
  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;
  return $results ;
}

function get_crs_name($dbc, $crs_id){
  require( 'includes/connect_db_c9.php' ) ; 
	$query = "SELECT CRS_NAME FROM COURSE WHERE CRS_ID = '$crs_id'";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if(!$results){
    	echo "didnt work";
    }
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$crs_name = $row ['CRS_NAME'];
	return $crs_name;
}

function get_crs_level($dbc, $crs_id){
  require( 'includes/connect_db_c9.php' ) ; 
	$query = "SELECT CRS_LEVEL FROM COURSE WHERE CRS_ID = '$crs_id'";
	//show_query($query) ;
    $results = mysqli_query( $dbc, $query ) ;
    if(!$results){
    	echo "didnt work";
    }
	$row = mysqli_fetch_array($results, MYSQLI_ASSOC) ;
	$crs_level = $row ['CRS_LEVEL'];
	return $crs_level;
}

function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}


?>