If you are getting a mysqli error, make sure the connection to the DB is open! Sometimes a function closes it. Also, make sure you close the DB connection when redirecting to another page.

Getting rid of bottom scrollbar:**
Replace page content div container with:
<div class="container-fluid">
Also make titles headers with <div class="page-header">

Jquery and php: http://stackoverflow.com/questions/607673/setting-a-php-sessionvar-using-jquery

Rename pages to not have zOS. That way, it's easier to duplicate for Data Center. MB guys -Kai
Our best bet is to have a folder named zOS and another folder named Data Center.

Importing data to database (!!!)
Import data into big fake table, insert select. (!!!)

Edit student info (X)
and courses they're taking (x)

error checking on add student form (X)
error checking on add course for student (X)
seeing detail info for student (X)
separate inactive, active courses (X)
list 3 recent active courses (X)

put courses for student on add course page (X)
be able to add course from add course for student page, and go back to where you were before (this will be a lot of work. need to save user progress on that page. there could be problems if there are fields not set.)
make them able to add an employer from add student screen (this will be a lot of work. need to save user progress on that page. there could be problems if there are fields not set.)

make user settings page
make IDCP settings page (top right)
	add employers
	add instructors

be able to search for students by name (who memorizes IDs)
display some students/courses in table when searching, or just give the whole list of students (!!!)
display current courses for student (X)

add success pages (for ones that aren't obvious) (X mostly)
add edit student's courses page (X)

get current year (X)

breadcrumbs: https://www.tutorialspoint.com/bootstrap/bootstrap_breadcrumb.htm (we should def put this in)
pagination: https://www.tutorialspoint.com/bootstrap/bootstrap_pagination.htm (meh)
cool tricks: https://scotch.io/bar-talk/bootstrap-3-tips-and-tricks-you-might-not-know#how-to-enable-bootstrap-3-hover-dropdowns