// $('.table > tbody > tr').click(function() {
//     // row was clicked
// });

// jQuery(document).ready(function($) {
//     $(".clickable-row").click(function() {
//         window.location = $(this).data("href");
//     });
// });