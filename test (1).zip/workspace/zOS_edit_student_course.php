<!DOCTYPE html>
<html lang="en">
    <!-- jQuery -->
    <!--<script type="text/javascript" src="js/jquery.js"></script>-->
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<?php
    
        session_start();
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/student_helpers.php' ) ;
        $stu_id = $_SESSION['stu_id'];
        $crs_id = $_SESSION['CRS_ID'];
        
        # Check to make sure it is the first time user is visiting the page
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        	$query = "SELECT * FROM CRS_ENROLLED WHERE STU_ID = $stu_id AND CRS_ID = $crs_id";
        	//show_query($query);
        	$result = mysqli_query($dbc, $query);
        	$row = mysqli_fetch_array($result, MYSQLI_ASSOC) ;
        	$credit = $row['CREDIT'];
        	if($credit == 1) $credit = 'Yes';
        	else $credit = 'No';
        	$grade = $row['GRADE'];
        	$crs_enroll_status = $row['CRS_ENROLL_STATUS'];
        	$crs_enroll_yr_start = $row['CRS_ENROLL_YR_START'];
        	$crs_enroll_mon_start = $row['CRS_ENROLL_MON_START'];
        	$crs_enroll_day_start = $row['CRS_ENROLL_DAY_START'];
        	$crs_enroll_yr_end = $row['CRS_ENROLL_YR_END'];
        	$crs_enroll_mon_end = $row['CRS_ENROLL_MON_END'];
        	$crs_enroll_day_end = $row['CRS_ENROLL_DAY_END'];
        	}
        else{
            echo '<p>'.mysqli_error($dbc).'</p>';
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
        	$credit = $_POST['credit'];
        	if($credit == 'Yes'){
        	    $credit = 1;
        	}
        	else{
        	    $credit = 0;
        	}
        	$grade = $_POST['grade'];
        	$crs_enroll_status = $_POST['crs_enroll_status'];
        	$crs_enroll_yr_start = $_POST['crs_enroll_yr_start'];
        	$crs_enroll_mon_start = $_POST['crs_enroll_mon_start'];
        	$crs_enroll_day_start = $_POST['crs_enroll_day_start'];
        	$crs_enroll_yr_end = $_POST['crs_enroll_yr_end'];
        	$crs_enroll_mon_end = $_POST['crs_enroll_mon_end'];
        	$crs_enroll_day_end = $_POST['crs_enroll_day_end'];
        	var_dump( $_POST );
    		$grade = trim($grade);
    		if(!isset($crs_enroll_mon_end)){ 
        	    $crs_enroll_yr_end = 'NULL';
        	}
        	if(!isset($crs_enroll_yr_end)){
        	    $crs_enroll_yr_end = 'NULL';
        	}
        	if(!isset($crs_enroll_day_end)){
        	    $crs_enroll_day_end = 'NULL';
        	}
    		$result = update_record_crs_enrolled($dbc, $credit, $grade, $crs_enroll_status, $crs_enroll_yr_start, $crs_enroll_mon_start, $crs_enroll_day_start, $crs_enroll_yr_end, $crs_enroll_mon_end, $crs_enroll_day_end, $crs_id, $stu_id);
    		$page = 'zOS_edit_student_courses_home.php';
            header("Location: $page");
        }
        //If the user clicks on a link, the GET method will be returned, so run this else-if block to show the user more information about the president
        else if($_SERVER['REQUEST_METHOD'] == 'GET'){
        	if(isset($_GET['id']))
        		show_record($dbc, $_GET['id']);
        }
        # Show the records
        //show_link_records($dbc);
        # Close the connection
        mysqli_close( $dbc ) ;
        
        ?>
<head>
    
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IDCP</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <!--<link href="css/simple-sidebar.css" rel="stylesheet">-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/banner.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
</head>

<body>
    <img src='placeholder.png' style="visibility: hidden;" id="banner">
	<!--Navigation Bars-->
    <div id="wrapper container"> <!--Added wrapper container so there won't be a scroll bar at the bottom-->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <img src="IDCPlogo.PNG" id="banner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="user_settings.php"><i class="fa fa-fw fa-user"></i> User Settings</a>
                        </li>
                        <li>
                            <a href="idcp_settings.php"><i class="fa fa-fw fa-gear"></i> IDCP Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        <!--</div>-->
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" style="margin-top:7%;">
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#zOS"> z/OS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="zOS" class="collapse">
                            <li>
                                <a href="zOS_student.php">Students</a>
                            </li>
                            <li>
                                <a href="zOS_course.php">Courses</a>
                            </li>
                            <li>
                                <a href="generate_report.php">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#dataCenter"> Data Center <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="dataCenter" class="collapse">
                            <li>
                                <a href="#">Students</a>
                            </li>
                            <li>
                                <a href="#">Courses</a>
                            </li>
                            <li>
                                <a href="#">Report</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <!-- Page Content -->
        <div id="page-content-wrapper" style="margin-left: 250px;">
            <div class="container" style="padding-right: 100px; max-width: 1050px;">
                <div class="dropdown">
                    <div class="row">
                        <div class="page-header">
                            <?php
        				        $stu_id = $_SESSION['stu_id'];
        				        $name = get_stu_name($dbc, $stu_id);
        				        $crs_name = get_crs_name($dbc, $crs_id);
        				        echo '<h1>Edit ' .$crs_name. ' Enrollment Info for ' . "$name" . '</h1>';
    				        ?>
                        </div>
                    </div>
                    <form action="zOS_edit_student_course.php" method="POST" class="form-horizontal" data-toggle="validator" id="edit_student_course">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Standing</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Enrollment Status*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_status" value="<?php if (isset($_POST['crs_enroll_status'])) echo $_POST['crs_enroll_status'];?>" data-error="Please select the student's enrollment status" required>
                                    <option disabled selected value> -- </option>
                                    <?php
                                        $selected = $crs_enroll_status;
                                        $statuses = array("Active", "Completed", "Failed", "Dropped");
                                        foreach($statuses as $status){
                                            if($selected == $status){
                                                echo "<option selected='selected' value='$status'>$status</option>" ;
                                            }else{
                                                echo "<option value='$status'>$status</option>" ;
                                            }
                                        }                                  
                                    ?>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Grade</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="grade" value="<?php if (isset($_POST['grade'])) echo $_POST['grade']; else echo $grade;?>">
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Taking for Credit?*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="credit" value="<?php if (isset($_POST['credit'])) echo $_POST['credit'];?>" data-error="Please select if the student is taking the course for credit" required>
                                    <option disabled selected value>--</option>
                                    <option <?php if($credit == 1) echo 'selected="selected"' ?>>Yes</option>
                                    <option <?php if($credit == 0) echo 'selected="selected"' ?>>No</option>
                                  </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Time Interval</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Enroll Year*</label>
                            <div class="col-xs-2">
                                    <select class="form-control" id="sel1" name="crs_enroll_yr_start" value="<?php if (isset($_POST['crs_enroll_yr_start'])) echo $_POST['crs_enroll_yr_start'];?>" data-error="Please select the student's enroll year" required>
                                        <option disabled selected value>--</option>
                                        <?php
                                        $selected = $crs_enroll_yr_start;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                                  </select>
                                </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Enroll Month*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_mon_start" value="<?php if (isset($_POST['crs_enroll_mon_start'])) echo $_POST['crs_enroll_mon_start'];?>" data-error="Please select the student's enroll month" required>
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $crs_enroll_mon_start;
                                        $monthnums = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
                                        $months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                                        foreach($monthnums as $monthnum){
                                            $monthname = $months[$monthnum-1];
                                            if($selected == $monthnum){
                                                echo "<option selected='selected' value='$monthnum'>$monthname</option>" ;
                                            }else{
                                                echo "<option value='$monthnum'>$monthname</option>" ;
                                            }
                                        }
                                    ?>
                              </select>                         
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Enroll Day*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_day_start" value="<?php if (isset($_POST['crs_enroll_day_start'])) echo $_POST['crs_enroll_day_start'];?>" data-error="Please select the student's enroll day" required>
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $crs_enroll_day_start;
                                        $day = 1;
                                        while($day <= 31){
                                            if($selected == $day){
                                                echo "<option selected='selected' value='$day'>$day</option>" ;
                                                $day++;
                                            }else{
                                                echo "<option value='$day'>$day</option>" ;
                                                $day++;
                                            }
                                        }                                  
                                        ?>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">End Year</label>
                            <div class="col-xs-2">
                                    <select class="form-control" id="sel1" name="crs_enroll_yr_end" value="<?php if (isset($_POST['crs_enroll_yr_end'])) echo $_POST['crs_entroll_yr_end'];?>">
                                        <option disabled selected value>--</option>
                                        <?php
                                        $selected = $crs_enroll_yr_end;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                                  </select>
                                </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">End Month</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_mon_end" value="<?php if (isset($_POST['crs_enroll_mon_end'])) echo $_POST['crs_enroll_mon_end'];?>">
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $crs_enroll_mon_end;
                                        $monthnums = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
                                        $months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                                        foreach($monthnums as $monthnum){
                                            $monthname = $months[$monthnum-1];
                                            if($selected == $monthnum){
                                                echo "<option selected='selected' value='$monthnum'>$monthname</option>" ;
                                            }else{
                                                echo "<option value='$monthnum'>$monthname</option>" ;
                                            }
                                        }
                                    ?>
                              </select>                         
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">End Day</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="crs_enroll_day_end" value="<?php if (isset($_POST['crs_enroll_day_end'])) echo $_POST['crs_enroll_day_end'];?>">
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $crs_enroll_day_end;
                                        $day = 1;
                                        while($day <= 31){
                                            if($selected == $day){
                                                echo "<option selected='selected' value='$day'>$day</option>" ;
                                                $day++;
                                            }else{
                                                echo "<option value='$day'>$day</option>" ;
                                                $day++;
                                            }
                                        }                                  
                                        ?>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
    </div>
    <!-- /#wrapper -->

    <!--<script type="text/javascript" src="js/jquery.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>
    
    <script>
        // window.onload = function() {
        //     if (window.jQuery) {  
        //         // jQuery is loaded  
        //         alert("Yeah!");
        //     } else {
        //         // jQuery is not loaded
        //         alert("Doesn't Work");
        //     }
        // }
    </script>
    

</body>

</html>
