<!DOCTYPE html>
<html lang="en">
<?php 
    session_start(); 
    require( 'includes/connect_db_c9.php' ) ;
    require( 'includes/student_helpers.php' ) ;
?>


<style>
    .inline {
  display: inline;
}

.link-button {
  background: none;
  border: none;

}
.link-button:focus {
  outline: none;


}

.link-button:hover {
  outline: none;
  

}
.link-button:active {
  color:white;
}
</style>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IDCP</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <!--<link href="css/simple-sidebar.css" rel="stylesheet">-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/banner.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
</head>

<body>
    <img src='placeholder.png' style="visibility: hidden;" id="banner">
	<!--Navigation Bars-->
    <div id="wrapper">
        <!--<img src="IDCPorig.png" id="banner">-->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <img src="IDCPlogo.PNG" id="banner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="user_settings.php"><i class="fa fa-fw fa-user"></i> User Settings</a>
                        </li>
                        <li>
                            <a href="idcp_settings.php"><i class="fa fa-fw fa-gear"></i> IDCP Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" style="margin-top:7%;">
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#zOS"> z/OS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="zOS" class="collapse">
                            <li>
                                <a href="zOS_student.php">Students</a>
                            </li>
                            <li>
                                <a href="zOS_course.php">Courses</a>
                            </li>
                            <li>
                                <a href="generate_report.php">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#dataCenter"> Data Center <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="dataCenter" class="collapse">
                            <li>
                                <a href="#">Students</a>
                            </li>
                            <li>
                                <a href="#">Courses</a>
                            </li>
                            <li>
                                <a href="#">Report</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <!-- Page Content -->
        <?php
        # Connect to MySQL server and the database
        require( 'includes/report_helpers.php' ) ;
        ?>
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1000px;">-->
                <div class="page-header">
                    <h1>
                        <?php
                            $stu_id = $_SESSION['stu_id'];
                            echo get_stu_name($dbc, $stu_id);
                        ?>
                    </h1>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    <!--<form method="get" action="zOS_edit_student.php" class="inline">-->
                                    <!--  <input type="hidden" name="student_ID" value="<?php //echo $stu_id; ?>">-->
                                    <!--    <button type="submit" class="link-button">-->
                                    <!--        Edit Student Info-->
                                    <!--    </button>-->
                                    <!--  </form>-->
                                    <!--<a href="zOS_edit_student.php">Student Info</a>-->
                                    Personal Info
                                </h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <p><label>ID</label><br>
                                        <?php
    				                        echo $stu_id;                                
    				                    ?>
				                    </p>
                                    <p><label>Gender</label><br>
                                        <?php
                                         echo get_stu_gender($dbc, $stu_id);
                                        ?>
                                    </p>
                                    <p><label>Student Since</label><br>
                                        <?php
                                         echo month_num_to_name(get_stu_mon_start($dbc, $stu_id));
                                         echo " ";
                                         echo get_stu_day_start($dbc, $stu_id);
                                         echo ", ";
                                         echo get_stu_yr_start($dbc, $stu_id);
                                        ?>
                                    </p>
                                    <button class="btn btn-default btn-sm" onclick="location.href='student_profile_detail.php';">View More</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='zOS_edit_student.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><a href='student_course.php'>Courses</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <?php
                                        show_recent_student_courses($dbc, $stu_id);
                                    ?>
                                <button class="btn btn-default btn-sm" onclick="location.href='zOS_edit_student_courses_home.php';">View More</button>
                                    <button class="btn btn-default btn-sm" onclick ="location.href='zOS_edit_student_courses_home.php';">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-sm-4 -->
                    <div class="col-sm-4">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <h3 class="panel-title"><a href='student_certificate.php'>Certificate(s)</a></h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <?php
                                    $id=20034567;
                                    show_stu_cert($dbc,$id);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- /#container close -->
            </div>
        <!-- /#page-content-wrapper -->
        </div>
    </div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


</body>

</html>
