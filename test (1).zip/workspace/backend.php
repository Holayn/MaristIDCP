<?php
session_start();
$_SESSION['CRS_ID'] = $_POST['CRS_ID'];
//Close any existing db connections
mysqli_close( $dbc ) ;
?>