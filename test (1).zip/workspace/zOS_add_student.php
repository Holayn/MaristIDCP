<!--Form for adding a new student-->
<!DOCTYPE html>
<html lang="en">
<?php
        # Connect to MySQL server and the database
        require( 'includes/connect_db_c9.php' ) ;
        # Includes these helper functions
        require( 'includes/student_helpers.php' ) ;
        # Check to make sure it is the first time user is visiting the page
        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        	$stu_id = "";
        	$stu_tag = "";
        	$stu_fname = "";
        	$stu_lname = "";
        	$stu_initial = "";
        	$stu_gender = "";
        	$stu_citizen = "";
        	$stu_street = "";
        	$stu_city = "";
        	$stu_zip = "";
        	$stu_country = "";
        	$stu_ethnicity = "";
        	$stu_yr_dob = "";
        	$stu_mon_dob = "";
        	$stu_day_dob = "";
        	$stu_edu_lvl = "";
        	$stu_transcript = "";
        	$stu_email_1 = "";
        	$stu_email_2 = "";
        	$stu_phone = "";
        	$stu_yr_start = "";
        	$stu_mon_start = "";
        	$stu_day_start = "";
        	$stu_comment = "";
        	$stu_qualify_exam = "";
        	$emp_id = "";
        	$stu_job_title = "";
        	$stu_state = "";
        }
        # Check to make sure the form method is post
        if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
        	$stu_id = $_POST['stu_id'];
        	$stu_tag = $_POST['stu_tag'];
        	$stu_fname = $_POST['stu_fname'];
        	$stu_lname = $_POST['stu_lname'];
        	$stu_initial = $_POST['stu_initial'];
        	$stu_gender = $_POST['stu_gender'];
        	$stu_citizen = $_POST['stu_citizen'];
        	$stu_street = $_POST['stu_street'];
        	$stu_city = $_POST['stu_city'];
        	$stu_zip = $_POST['stu_zip'];
        	$stu_country = $_POST['stu_country'];
        	$stu_ethnicity = $_POST['stu_ethnicity'];
        	$stu_yr_dob = $_POST['stu_yr_dob'];
        	$stu_mon_dob = $_POST['stu_mon_dob'];
        	$stu_day_dob = $_POST['stu_day_dob'];
        	$stu_edu_lvl = $_POST['stu_edu_lvl'];
        	$stu_transcript = $_POST['stu_transcript'];
        	$stu_email_1 = $_POST['stu_email_1'];
        	$stu_email_2 = $_POST['stu_email_2'];
        	$stu_phone = $_POST['stu_phone'];
        	$stu_yr_start = $_POST['stu_yr_start'];
        	$stu_mon_start = $_POST['stu_mon_start'];
        	$stu_day_start = $_POST['stu_day_start'];
        	$stu_comment = $_POST['stu_comment'];
        	$stu_qualify_exam = $_POST['stu_qualify_exam'];
        	$emp_id = $_POST['emp_name'];
        	$stu_job_title = $_POST['stu_job_title'];
        	$stu_state = $_POST['stu_state'];
        	
        	//ID is stored in DB, not the name. Also need to populate dropdown with employer names
        	$emp_id = get_employer_id($dbc, $emp_id);
        	
        	if($stu_citizen == "Yes"){
        	    $stu_citizen = 1;
        	}
        	else{
        	    $stu_citizen = 0;
        	}
        	if($stu_transcript == "Yes"){
        	    $stu_transcript = 1;
        	}
        	else{
        	    $stu_transcript = 0;
        	}
        	if($stu_qualify_exam == "Yes"){
        	    $stu_qualify_exam = 1;
        	}
        	else{
        	    $stu_qualify_exam = 0;
        	}
        	if($stu_mon_dob == "January"){
        	    $stu_mon_dob = 1;
        	}
        	if($stu_mon_dob == "February"){
        	    $stu_mon_dob = 2;
        	}
        	if($stu_mon_dob == "March"){
        	    $stu_mon_dob = 3;
        	}
        	if($stu_mon_dob == "April"){
        	    $stu_mon_dob = 4;
        	}
        	if($stu_mon_dob == "May"){
        	    $stu_mon_dob = 5;
        	}
        	if($stu_mon_dob == "June"){
        	    $stu_mon_dob = 6;
        	}
        	if($stu_mon_dob == "July"){
        	    $stu_mon_dob = 7;
        	}
        	if($stu_mon_dob == "August"){
        	    $stu_mon_dob = 8;
        	}
        	if($stu_mon_dob == "September"){
        	    $stu_mon_dob = 9;
        	}
        	if($stu_mon_dob == "October"){
        	    $stu_mon_dob = 10;
        	}
        	if($stu_mon_dob == "November"){
        	    $stu_mon_dob = 11;
        	}
        	if($stu_mon_dob == "December"){
        	    $stu_mon_dob = 12;
        	}
        	if($stu_mon_start == "January"){
        	    $stu_mon_start = 1;
        	}
        	if($stu_mon_start == "February"){
        	    $stu_mon_start = 2;
        	}
        	if($stu_mon_start == "March"){
        	    $stu_mon_start = 3;
        	}
        	if($stu_mon_start == "April"){
        	    $stu_mon_start = 4;
        	}
        	if($stu_mon_start == "May"){
        	    $stu_mon_start = 5;
        	}
        	if($stu_mon_start == "June"){
        	    $stu_mon_start = 6;
        	}
        	if($stu_mon_start == "July"){
        	    $stu_mon_start = 7;
        	}
        	if($stu_mon_start == "August"){
        	    $stu_mon_start = 8;
        	}
        	if($stu_mon_start == "September"){
        	    $stu_mon_start = 9;
        	}
        	if($stu_mon_start == "October"){
        	    $stu_mon_start = 10;
        	}
        	if($stu_mon_start == "November"){
        	    $stu_mon_start = 11;
        	}
        	if($stu_mon_start == "December"){
        	    $stu_mon_start = 12;
        	}
    		#Inserts inputs into table if all inputs are valid
    		$stu_fname = trim($stu_fname);
    		$stu_lname = trim($stu_lname);
    		$stu_initial = trim($stu_initial);
    		$stu_id = trim($stu_id);
    		$stu_tag = trim($stu_tag);
    		$stu_street = trim($stu_street);
    		$stu_city = trim($stu_city);
    		$stu_zip = trim($stu_zip);
    		$stu_email_1 = trim($stu_email_1);
    		$stu_email_2 = trim($stu_email_2);
    		$stu_phone = trim($stu_phone);
    		$emp_id = trim($emp_id);
    		$stu_job_title = trim($stu_job_title);
    		$result = insert_record($dbc, $stu_id, $stu_tag, $stu_lname, $stu_fname, $stu_initial, $stu_yr_start, $stu_mon_start, $stu_day_start, $stu_edu_lvl, $stu_job_title, $stu_street, $stu_city, $stu_state, $stu_country, $stu_zip, $stu_phone, $stu_email_1, $stu_email_2, $stu_yr_dob, $stu_mon_dob, $stu_day_dob, $stu_ethnicity, $stu_gender, $stu_citizen, $stu_transcript, $stu_qualify_exam, $stu_comment, $emp_id);
    		echo "Success! Thanks" ; 
    		
    		//PASSING STUDENT ID TO NEXT PAGE
    		
    		load('zOS_add_student_course_home.php', $stu_id);
        }
        # Close the connection
        mysqli_close( $dbc ) ;
        ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>IDCP</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <!--<link href="css/simple-sidebar.css" rel="stylesheet">-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/banner.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    
</head>

<body>
    <img src='placeholder.png' style="visibility: hidden;" id="banner">
	<!--Navigation Bars-->
    <div id="wrapper">
        <!--<img src="IDCPorig.png" id="banner">-->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <img src="IDCPlogo.PNG" id="banner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Home</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="user_settings.php"><i class="fa fa-fw fa-user"></i> User Settings</a>
                        </li>
                        <li>
                            <a href="idcp_settings.php"><i class="fa fa-fw fa-gear"></i> IDCP Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        <!--</div>-->
        <!--<div id="wrapper">-->
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
             <!--top: 145px;-->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" style="margin-top:7%;">
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#zOS"> z/OS <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="zOS" class="collapse">
                            <li>
                                <a href="zOS_student.php">Students</a>
                            </li>
                            <li>
                                <a href="zOS_course.php">Courses</a>
                            </li>
                            <li>
                                <a href="generate_report.php">Report</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#dataCenter"> Data Center <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="dataCenter" class="collapse">
                            <li>
                                <a href="#">Students</a>
                            </li>
                            <li>
                                <a href="#">Courses</a>
                            </li>
                            <li>
                                <a href="#">Report</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
            <!--<div class="container" style="padding-right: 100px; max-width: 1100px;">-->
                <div class="dropdown">
                    <div class="page-header">
                        <h1>z/OS Add a Student</h1>
                    </div>
                    <form action="zOS_add_student.php" method="POST" class="form-horizontal" role="form" data-toggle="validator" id="student_form">
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Identification</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">ID*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="stu_id" value="<?php if (isset($_POST['stu_id'])) echo $_POST['stu_id'];?>" data-error="Please enter the student's ID" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Tag*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="stu_tag" value="<?php if (isset($_POST['stu_tag'])) echo $_POST['stu_tag'];?>" data-error="Please enter the student's tag" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">First Name*</label>
                            <div class="col-xs-3">
                                <input type="text" class="form-control" name="stu_fname" value="<?php if (isset($_POST['stu_fname'])) echo $_POST['stu_fname'];?>" data-error="Please enter the student's first name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Last Name*</label>
                            <div class="col-xs-3">
                                <input type="text" class="form-control" name="stu_lname" value="<?php if (isset($_POST['stu_lname'])) echo $_POST['stu_lname'];?>" data-error="Please enter the student's last name" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Initial</label>
                            <div class="col-xs-1">
                                <input type="text" class="form-control" name="stu_initial" value="<?php if (isset($_POST['stu_initial'])) echo $_POST['stu_initial'];?>">
                                <!--<input type="text" class="form-control" name="stu_initial" value="<?php if (isset($_POST['stu_initial'])) echo $_POST['stu_initial'];?>" data-error="Please enter the student's initial" required>-->
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Gender*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_gender" value="<?php if (isset($_POST['stu_gender'])) echo $_POST['stu_gender'];?>" data-error="Please select the student's gender" required>
                                    <option disabled selected value> -- select an option -- </option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">U.S. Citizen*</label>
                            <div class="col-xs-1">
                                <select class="form-control" id="sel1" name="stu_citizen" value="<?php if (isset($_POST['stu_citizen'])) echo $_POST['stu_citizen'];?>" data-error="Please select if the student is a U.S. citizen" required>
                                    <option disabled selected value>--</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Street Address*</label>
                            <div class="col-xs-4">
                                <input type="text" class="form-control" name="stu_street" value="<?php if (isset($_POST['stu_street'])) echo $_POST['stu_street'];?>" data-error="Please enter the student's street address" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">City*</label>
                            <div class="col-xs-3">
                                <input type="text" class="form-control" name="stu_city" value="<?php if (isset($_POST['stu_city'])) echo $_POST['stu_city'];?>" data-error="Please enter the student's city" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">State*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="stu_state" value="<?php if (isset($_POST['stu_state'])) echo $_POST['stu_state'];?>" data-error="Please select the student's state" required>
                                    <option disabled selected value> -- select an option -- </option>
                                    <option value="AL">Alabama</option>
                                	<option value="AK">Alaska</option>
                                	<option value="AZ">Arizona</option>
                                	<option value="AR">Arkansas</option>
                                	<option value="CA">California</option>
                                	<option value="CO">Colorado</option>
                                	<option value="CT">Connecticut</option>
                                	<option value="DE">Delaware</option>
                                	<option value="DC">District Of Columbia</option>
                                	<option value="FL">Florida</option>
                                	<option value="GA">Georgia</option>
                                	<option value="HI">Hawaii</option>
                                	<option value="ID">Idaho</option>
                                	<option value="IL">Illinois</option>
                                	<option value="IN">Indiana</option>
                                	<option value="IA">Iowa</option>
                                	<option value="KS">Kansas</option>
                                	<option value="KY">Kentucky</option>
                                	<option value="LA">Louisiana</option>
                                	<option value="ME">Maine</option>
                                	<option value="MD">Maryland</option>
                                	<option value="MA">Massachusetts</option>
                                	<option value="MI">Michigan</option>
                                	<option value="MN">Minnesota</option>
                                	<option value="MS">Mississippi</option>
                                	<option value="MO">Missouri</option>
                                	<option value="MT">Montana</option>
                                	<option value="NE">Nebraska</option>
                                	<option value="NV">Nevada</option>
                                	<option value="NH">New Hampshire</option>
                                	<option value="NJ">New Jersey</option>
                                	<option value="NM">New Mexico</option>
                                	<option value="NY">New York</option>
                                	<option value="NC">North Carolina</option>
                                	<option value="ND">North Dakota</option>
                                	<option value="OH">Ohio</option>
                                	<option value="OK">Oklahoma</option>
                                	<option value="OR">Oregon</option>
                                	<option value="PA">Pennsylvania</option>
                                	<option value="RI">Rhode Island</option>
                                	<option value="SC">South Carolina</option>
                                	<option value="SD">South Dakota</option>
                                	<option value="TN">Tennessee</option>
                                	<option value="TX">Texas</option>
                                	<option value="UT">Utah</option>
                                	<option value="VT">Vermont</option>
                                	<option value="VA">Virginia</option>
                                	<option value="WA">Washington</option>
                                	<option value="WV">West Virginia</option>
                                	<option value="WI">Wisconsin</option>
                                	<option value="WY">Wyoming</option> 
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">ZIP*</label>
                            <div class="col-xs-2">
                                <input type="text" class="form-control" name="stu_zip" value="<?php if (isset($_POST['stu_zip'])) echo $_POST['stu_zip'];?>" data-error="Please enter the student's ZIP code" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Country*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="stu_country" value="<?php if (isset($_POST['stu_country'])) echo $_POST['stu_country'];?>" data-error="Please select the student's country" required>
                                    <option disabled selected value> -- select an option -- </option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Åland Islands">Åland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Bahamas">Bahamas</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belarus">Belarus</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Belize">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Bouvet Island">Bouvet Island</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                    <option value="Brunei Darussalam">Brunei Darussalam</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Cameroon">Cameroon</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Central African Republic">Central African Republic</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China">China</option>
                                    <option value="Christmas Island">Christmas Island</option>
                                    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Congo">Congo</option>
                                    <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Cote D'ivoire">Cote D'ivoire</option>
                                    <option value="Croatia">Croatia</option>
                                    <option value="Cuba">Cuba</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czechia">Czechia</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="Egypt">Egypt</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji">Fiji</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="French Southern Territories">French Southern Territories</option>
                                    <option value="Gabon">Gabon</option>
                                    <option value="Gambia">Gambia</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Ghana">Ghana</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guam">Guam</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guernsey">Guernsey</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guinea-bissau">Guinea-bissau</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Haiti">Haiti</option>
                                    <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                    <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong">Hong Kong</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                    <option value="Iraq">Iraq</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Isle of Man">Isle of Man</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jersey">Jersey</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                    <option value="Korea, Republic of">Korea, Republic of</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lebanon">Lebanon</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liberia">Liberia</option>
                                    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Macao">Macao</option>
                                    <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mayotte">Mayotte</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                    <option value="Moldova, Republic of">Moldova, Republic of</option>
                                    <option value="Monaco">Monaco</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montenegro">Montenegro</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Myanmar">Myanmar</option>
                                    <option value="Namibia">Namibia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherlands">Netherlands</option>
                                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Nigeria">Nigeria</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Palau">Palau</option>
                                    <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                    <option value="Paraguay">Paraguay</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Philippines">Philippines</option>
                                    <option value="Pitcairn">Pitcairn</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Puerto Rico">Puerto Rico</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Reunion">Reunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russian Federation">Russian Federation</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="Saint Helena">Saint Helena</option>
                                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                    <option value="Saint Lucia">Saint Lucia</option>
                                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Serbia">Serbia</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Slovakia">Slovakia</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="Sudan">Sudan</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                    <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Timor-leste">Timor-leste</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tokelau">Tokelau</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="United States">United States</option>
                                    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                    <option value="Uruguay">Uruguay</option>
                                    <option value="Uzbekistan">Uzbekistan</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Venezuela">Venezuela</option>
                                    <option value="Viet Nam">Viet Nam</option>
                                    <option value="Virgin Islands, British">Virgin Islands, British</option>
                                    <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                    <option value="Wallis and Futuna">Wallis and Futuna</option>
                                    <option value="Western Sahara">Western Sahara</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Zambia">Zambia</option>
                                    <option value="Zimbabwe">Zimbabwe</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Ethnicity*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="stu_ethnicity" value="<?php if (isset($_POST['stu_ethnicity'])) echo $_POST['stu_ethnicity'];?>" data-error="Please select the student's ethnicity" required>
                                    <option disabled selected value> -- select an option -- </option>
                                    <option>Mixed Race</option>
                                    <option>Arctic (Siberian, Eskimo)</option>
                                    <option>Caucasian (European)</option>
                                    <option>Caucasian (Indian)</option>
                                    <option>Caucasian (Middle East)</option>
                                    <option>Caucasian (North African, Other)</option>
                                    <option>Indigenous Australian</option>
                                    <option>Native American</option>
                                    <option>North East Asian (Mongol, Tibetan, Korean Japanese, etc)</option>
                                    <option>Pacific (Polynesian, Micronesian, etc)</option>
                                    <option>South East Asian (Chinese, Thai, Malay, Filipino, etc)</option>
                                    <option>West African, Bushmen, Ethiopian</option>
                                    <option>Other Race</option>
                                </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <!--<div class="row">-->
                                <label class="col-xs-3 control-label" for="sel1">Birth Year*</label>
                                <div class="col-xs-2">
                                    <select class="form-control" id="sel1" name="stu_yr_dob" value="<?php if (isset($_POST['stu_yr_dob'])) echo $_POST['stu_yr_dob'];?>" data-error="Please select the student's birth year" required>
                                        <option disabled selected value>--</option>
                                        <?php
                                        $selected = $stu_yr_dob;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                                  </select>
                                </div>
                                <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Birth Month*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_mon_dob" value="<?php if (isset($_POST['stu_mon_dob'])) echo $_POST['stu_mon_dob'];?>" data-error="Please select the student's month of birth" required>
                                    <option disabled selected value>--</option>
                                    <option>January</option>
                                    <option>February</option>
                                    <option>March</option>
                                    <option>April</option>
                                    <option>May</option>
                                    <option>June</option>
                                    <option>July</option>
                                    <option>August</option>
                                    <option>September</option>
                                    <option>October</option>
                                    <option>November</option>
                                    <option>December</option>
                                  </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Birth Day*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_day_dob" value="<?php if (isset($_POST['stu_day_dob'])) echo $_POST['stu_day_dob'];?>" data-error="Please select the student's day of birth" required>
                                    <option disabled selected value>--</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                    <option>16</option>
                                    <option>17</option>
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Education</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Highest Education Level*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_edu_lvl" value="<?php if (isset($_POST['stu_edu_lvl'])) echo $_POST['stu_edu_lvl'];?>" data-error="Please select the student's education level" required>
                                    <option disabled selected value> -- select an option -- </option>
                                    <option>Doctor's</option>
                                    <option>Master's</option>
                                    <option>Bachelor's</option>
                                    <option>Associate's</option>
                                    <option>Some four year college</option>
                                    <option>Some two year college</option>
                                    <option>High School</option>
                                    <option>None</option>
                                    <option>Other</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Transcript Received*</label>
                            <div class="col-xs-1">
                                <select class="form-control" id="sel1" name="stu_transcript" value="<?php if (isset($_POST['stu_transcript'])) echo $_POST['stu_transcript'];?>" data-error="Please select if the student's transcript was received" required>
                                    <option disabled selected value>--</option>
                                    <option>Yes</option>
                                    <option>No</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Contact & Employer</h3>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Email 1*</label>
                            <div class="col-xs-4">
                                <input type="text" class="form-control" name="stu_email_1" value="<?php if (isset($_POST['stu_email_1'])) echo $_POST['stu_email_1'];?>" data-error="Please enter the student's first email" required>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Email 2</label>
                            <div class="col-xs-4">
                                <input type="text" class="form-control" name="stu_email_2" value="<?php if (isset($_POST['stu_email_2'])) echo $_POST['stu_email_2'];?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Phone*</label>
                            <div class="col-xs-3">
                                <input type="text" onkeypress="return isNumberKey(event)" placeholder="1234567890" class="form-control" name="stu_phone" value="<?php if (isset($_POST['stu_phone'])) echo $_POST['stu_phone'];?>" data-error="Please enter the student's phone number" required>
                            </div>
                            <div class="help-block with-errors"></div>
                            <!--Only allows numbers for input-->
                            <script>
                                function isNumberKey(evt){
                                    var charCode = (evt.which) ? evt.which : event.keyCode
                                    if (charCode > 31 && (charCode < 48 || charCode > 57))
                                        return false;
                                    return true;
                                }
                            </script>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Employer*</label>
                            <div class="col-xs-3">
                                <select class="form-control" id="sel1" name="emp_name" value="<?php if (isset($_POST['emp_name'])) echo $_POST['emp_name'];?>" data-error="Please select the student's employer" required>
                                <option disabled selected value>-- select an option --</option>
                                <?php
                                    require('includes/connect_db_c9.php');
                                    $query = 'SELECT EMP_NAME FROM EMPLOYER';
	                                $results = mysqli_query($dbc, $query);
	                                if($results){
	                                    while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
                                		{
                                			echo '<option>' . $row['EMP_NAME'] . '</option>' ;
                                		}
	                                }
	                                else
                                	{
                                		echo '<p>' . mysqli_error( $dbc ) . '</p>'  ;
                                	}
                                	echo '<option>None</option>';
                                	# Free up the results in memory
                                	mysqli_free_result( $results );
                                	mysqli_close( $dbc ) ;
                                ?>
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                            <button class="btn btn-default" onclick="location.href='zOS.html';">Add an Employer</button>
                            
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Job Title</label>
                            <div class="col-xs-3">
                                <input type="text" class="form-control" name="stu_job_title" value="<?php if (isset($_POST['stu_job_title'])) echo $_POST['stu_job_title'];?>">
                                <!--<input type="text" class="form-control" name="stu_job_title" value="<?php if (isset($_POST['stu_job_title'])) echo $_POST['stu_job_title'];?>" data-error="Please enter the student's job title" required>-->
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Program Information</h3>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Year*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_yr_start" value="<?php if (isset($_POST['stu_yr_start'])) echo $_POST['stu_yr_start'];?>" data-error="Please select the student's start year" required>
                                    <option disabled selected value>--</option>
                                    <?php
                                        $selected = $stu_yr_start;
                                        $year = date("Y");
                                        $endyear = $year-100;
                                        while($year >= $endyear){
                                            if($selected == $year){
                                                echo "<option selected='selected' value='$year'>$year</option>" ;
                                                $year--;
                                            }else{
                                                echo "<option value='$year'>$year</option>" ;
                                                $year--;
                                            }
                                        }                                  
                                        ?>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Month*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_mon_start" value="<?php if (isset($_POST['stu_mon_start'])) echo $_POST['stu_mon_start'];?>" data-error="Please select the student's start month" required>
                                    <option disabled selected value>--</option>
                                    <option>January</option>
                                    <option>February</option>
                                    <option>March</option>
                                    <option>April</option>
                                    <option>May</option>
                                    <option>June</option>
                                    <option>July</option>
                                    <option>August</option>
                                    <option>September</option>
                                    <option>October</option>
                                    <option>November</option>
                                    <option>December</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Start Day*</label>
                            <div class="col-xs-2">
                                <select class="form-control" id="sel1" name="stu_day_start" value="<?php if (isset($_POST['stu_day_start'])) echo $_POST['stu_day_start'];?>" data-error="Please select the student's start day" required>
                                    <option disabled selected value>--</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                    <option>6</option>
                                    <option>7</option>
                                    <option>8</option>
                                    <option>9</option>
                                    <option>10</option>
                                    <option>11</option>
                                    <option>12</option>
                                    <option>13</option>
                                    <option>14</option>
                                    <option>15</option>
                                    <option>16</option>
                                    <option>17</option>
                                    <option>18</option>
                                    <option>19</option>
                                    <option>20</option>
                                    <option>21</option>
                                    <option>22</option>
                                    <option>23</option>
                                    <option>24</option>
                                    <option>25</option>
                                    <option>26</option>
                                    <option>27</option>
                                    <option>28</option>
                                    <option>29</option>
                                    <option>30</option>
                                    <option>31</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label" for="sel1">Qualifying Exam*</label>
                            <div class="col-xs-1">
                                <select class="form-control" id="sel1" name="stu_qualify_exam" value="<?php if (isset($_POST['stu_qualify_exam'])) echo $_POST['stu_qualify_exam'];?>" data-error="Please select if the student has passed a qualifying exam" required>
                                    <option disabled selected value>--</option>
                                    <option>Yes</option>
                                    <option>No</option>
                              </select>
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label"></label>
                            <div class="col-xs-5">
                                <h3>Miscellaneous</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-xs-3 control-label">Comment</label>
                            <div class="col-xs-5">
                                <input type="text" class="form-control" name="stu_comment" value="<?php if (isset($_POST['stu_comment'])) echo $_POST['stu_comment'];?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-5 col-xs-offset-3">
                                <button type="submit" class="btn btn-default">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <!-- /#page-content-wrapper -->
        </div>
		    
    </div>
    <!-- /#wrapper -->

    <!--<script src="//cdnjs.buttflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>-->
    
    <script>
    //     $(document).ready(function() {
    //         $('#datePicker')
    //             .datepicker({
    //                 format: 'mm/dd/yyyy'
    //             })
    //             // .on('changeDate', function(e) {
    //             //     // Revalidate the date field
    //             //     $('#eventForm').formValidation('revalidateField', 'date');
    //             // });
    //     });
    // </script>
    <!--<script> $('.datepicker').datepicker(); </script>-->
    
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!-- Validator Bootstrap Plugin-->
    <script src="js/validator.js"></script>

</body>

</html>
